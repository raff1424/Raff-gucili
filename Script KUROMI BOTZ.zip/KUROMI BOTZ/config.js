// CREATE BY REZA DEVS KUROMI
function replacement(e) {
    return e.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
}
global.owner = "6283894064758@s.whatsapp.net", ///momer owner
 global.ownerName = "Reza", // nama owner 

global.developer = ["6283894064758", "6283190004491"].map(replacement), // nomer owner

global.botName = "KUROMI BOT", //.nama bot mu

global.apikey = "API-4bipdh8h5f", // jangan di ubah

global.fake = "", // wm

global.header = `KUROMI BOT v${require("./package.json").version} (Beta)`, // wm

global.footer = "ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ ᴍᴀᴅᴇ ʙʏ ʀᴇᴢᴀ", // wm
global.cooldown = 1, // jangan di ubah

global.max_ram = 3, // jangan di ubah

global.blocks = ["91", "92", "212"], // auto blocks nomer luar
 global.prefixes = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i,  // jangan di ubah 
 
global.newsletter = "120363375725098747@newsletter", // ubah ke id saluran mu

global.audioUrl = "https://cdn.filestackcontent.com/2r7cSUozTQ2tTS15NfFj", // buat lagu di menu

global.pairing = {
    copyFromLink: false,
    status: true, // falss kalau mau qr 
    number: "+62 895-0242-3402", // nomer bot 
    code: ""
}, global.config = {
    session: "session", // mama sesi
    online: true, // jangan di ubah 
    version: [2, 3e3, 1015901307],  // jangan di ubah 
    browser: ["Windows", "Chrome", "20.0.04"],  // jangan di ubah 
    button: true // false kalau ga mau ada button
}, 
global.quoteApi = "https://qc.botcahx.eu.org/generate", //jangan di ubah
global.mess = {
    wait: "Processed . . .",
    ok: "Successfully.",
    limit: "kamu telah mencapai limit harian dan akan di reset setiap jam 00.00\n- beli premium untuk mendapatkan unlimited limit.",
    premium: "yahh, kamu bukan user premium, beli premium dulu yuk",
    jadibot: "khusus user jadibot, ingin menjadikan bot trial ? ketik .jadibot-trial",
    owner: "This feature is only for owners.",
    devs: "This feature is only for developers.",
    group: "This feature will only work in groups.",
    private: "Use this feature in private chat.",
    admin: "This feature only for group admin.",
    botAdmin: "This feature will work when I become an admin",
    bot: "This feature can only be accessed by bots",
    wrong: "Wrong format!",
    error: {
        url: "URL is Invalid!",
        api: "Sorry an error occurred!"
    },
    block: {
        owner: "This feature is being blocked by owner!",
        system: "This feature is being blocked by system because an error occurred!"
    },
    query: "Enter search text",
    search: "Searching . . .",
    scrap: "Scrapping . . .",
    wrongFormat: "Incorrect format, please look at the menu again",
    game: "Bermain game di obrolan pribadi hanya untuk pengguna premium, tingkatkan ke paket premium hanya Rp. 20.000 selama 1 bulan."
}, require("./system/functions.js").reloadFile(__filename);