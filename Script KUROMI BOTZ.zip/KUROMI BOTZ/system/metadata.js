const {
    jidNormalizedUser
} = require('@whiskeysockets/baileys');
const func = require('./functions.js');
const chalk = require('chalk');
const cooldowns = {}; // Objek untuk menyimpan data cooldown

function isSpam(currentTime, groupId) {
    // Set cooldown
    if (!cooldowns[groupId]) cooldowns[groupId] = {
        lastMetadataTime: 0,
        spamCount: 0,
        cooldownActive: false,
    };

    if (currentTime - cooldowns[groupId].lastMetadataTime < 1000) {
        cooldowns[groupId].spamCount++;

        if (cooldowns[groupId].spamCount >= 3 && !cooldowns[groupId].cooldownActive) {
            cooldowns[groupId].cooldownActive = true; // Aktifkan cooldown
            console.log(chalk.yellowBright(`Cooldown aktif untuk group ${groupId} selama 30 detik.`));
            // Reset spamCount setelah 30 detik
            setTimeout(() => {
                cooldowns[groupId].spamCount = 0;
                cooldowns[groupId].cooldownActive = false; // Nonaktifkan cooldown
                console.log(chalk.greenBright(`Cooldown selesai untuk group ${groupId}.`));
            }, 1000 * 30);
            return true; // Spam
        }
        return true; // Spam
    } else {
        cooldowns[groupId].lastMetadataTime = currentTime; // Update waktu terakhir
        cooldowns[groupId].spamCount = 0; // Reset spamCount jika tidak spam
        return false; // Bukan spam
    }
}

module.exports = async (kuromi, groupId) => {
    try {
        const bot = jidNormalizedUser(kuromi.user.id);
        if (global.db.setting[bot] && global.db.setting[bot].maintenance) return;

        if (/^\d.*(@g\.us)$/.test(groupId)) {
            if (cooldowns[groupId] && cooldowns[groupId].cooldownActive) {
                return console.log(chalk.cyanBright(`get metadata group “${global.db.metadata[groupId]?.subject || groupId}“ sedang cooldown.`));
            }
            if (!global.db.metadata[groupId]) {
                const groupMetadata = await kuromi.groupMetadata(groupId).catch((_) => {});
                global.db.metadata[groupId] = {
                    ...groupMetadata
                };
                console.log(`Pembuatan metadata pada: ${groupId} telah siap`);
            } else {
                // Panggil fungsi yang dijaga dari spam
                await spamProtectedFunction(groupId);
            }
        }

        async function spamProtectedFunction(groupId) {
            let currentTime = Date.now(); // Ambil waktu sekarang
            // Cek spam get group metadata
            if (!isSpam(currentTime, groupId)) {
                const metaData = global.db.metadata[groupId];
                const groupMetadata = await kuromi.groupMetadata(groupId).catch((_) => {});

                // Mengubah database metadata jika group metadata mengalami perubahan
                if (JSON.stringify(metaData) !== JSON.stringify(groupMetadata)) {
                    global.db.metadata[groupId] = {
                        ...groupMetadata
                    };
                    console.log(`Metadata group “${global.db.metadata[groupId]?.subject || groupId}“ diperbarui.`);
                } else {
                    console.log(`Tidak ada perubahan pada metadata group “${global.db.metadata[groupId]?.subject || groupId}“`);
                }
            } else {
                console.log(chalk.redBright.bold(`get metadata “${global.db.metadata[groupId]?.subject || groupId}“ spam!`));
            }
        }
    } catch (error) {
        console.error(error);
    }
}

func.reloadFile(__filename);