//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch");exports.run={usage:["totaluser"],category:"owner",async:async(e,{kuromi:t,setting:r})=>{var a=Object.values(global.db.users),s=a.filter(e=>e.register),s=`Total User: *${a.length}* User
Registered: *${s.length}* User

`;s+=a.map((e,t)=>`${t+1}. @${e.jid.split("@")[0]} (${e.register?"Yes":"No"})`).join("\n"),t.sendMessageModify(e.chat,s,e,{title:global.header,body:global.footer,thumbnail:await(await fetch(r.cover)).buffer(),largeThumb:!0,expiration:e.expiration})},owner:!0};