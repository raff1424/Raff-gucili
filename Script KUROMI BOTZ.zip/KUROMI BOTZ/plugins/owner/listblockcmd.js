//CREATE BY REZA DEVS KUROMI
exports.run={usage:["listblockcmd"],hidden:["listblokcmd"],category:"owner",async:async(n,{setting:c})=>{if(0==c.blockcmd.length)return n.reply("Empty data.");var e="乂  *LIST BLOCK COMMANDS*\n\n",e=(e+=`Total: *${c.blockcmd.length}* commands blocked

`)+c.blockcmd.map(c=>"◦  "+(n.prefix+c)).join("\n");n.reply(e)}};