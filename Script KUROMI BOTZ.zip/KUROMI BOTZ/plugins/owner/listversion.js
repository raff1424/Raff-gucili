//CREATE BY REZA DEVS KUROMI
let exec=require("child_process").exec;exports.run={usage:["listversion"],use:"module",category:"owner",async:async(n,{func:e,kuromi:t})=>{if(!n.text)return n.reply(e.example(n.cmd,"fs"));exec(`npm view ${n.args[0]} versions --json`,async(e,r)=>{if(e)return n.reply(""+e);let s=`*LIST VERSION MODULE*

Result From : ${n.args[0]}
`;var a;for(a of JSON.parse(r))s+=`
$ npm i ${n.args[0]}@`+a;t.sendMessage(n.chat,{text:s},{quoted:n,ephemeralExpiration:n.expiration})})},owner:!0};