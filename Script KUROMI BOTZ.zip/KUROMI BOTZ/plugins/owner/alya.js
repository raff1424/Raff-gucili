//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch");exports.run={usage:[],hidden:["alya"],category:"owner",async:async(a,{kuromi:e})=>{try{var r=await fetch("https://api.alyachan.dev/v1/check-key?apikey=6nY0bL"),t=await r.json();if(!r.ok||!t.status)return a.reply("API Key tidak valid atau terjadi kesalahan pada server.");var i=t.data,n=`乂  *A L Y A - I N F O*

◦  Creator: ${t.creator}
◦  Status: ${i.premium?"Premium":"Free"}
◦  Limit: ${i.limit} dari 5000
◦  Expired At: ${i.expired_at}
◦  Joined At: `+i.joined_at;e.reply(a.chat,n,a)}catch(e){console.error(e),a.reply("Terjadi kesalahan saat menghubungi API AlyaChan. Silakan coba lagi nanti.")}},owner:!0};