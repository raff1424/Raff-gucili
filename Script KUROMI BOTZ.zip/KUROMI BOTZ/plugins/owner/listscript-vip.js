//CREATE BY REZA DEVS KUROMI
exports.run={usage:["listscript-vip"],hidden:["listsc-vip"],category:"owner",async:async(r,{})=>{var i=global.db.notifvip;if(0==i.length)return r.reply("Empty data.");if("now"===(r.text||"").toLowerCase()){let e=new Date,t=e.getDate(),a=e.getMonth()+1,n=e.getFullYear(),o=e.toLocaleDateString("id-ID",{weekday:"long"})+`, ${t}/${a}/`+n,l="*L I S T - S C R I P T - V I P*";i.filter(e=>e.date==o).forEach((e,t)=>{l=(l=(l=(l+=`

${t+1}. @`+e.number)+`
- Name: `+e.name)+`
- Total: `+e.connect)+`
- Last connect: ${e.date.split(",")[0]}, `+e.time}),r.reply(l)}else{let a="*L I S T - S C R I P T - V I P*";i.forEach((e,t)=>{a=(a=(a=(a+=`

${t+1}. @`+e.number)+`
- Name: `+e.name)+`
- Total: `+e.connect)+`
- Last connect: ${e.date.split(",")[0]}, `+e.time}),await r.reply(a)}},owner:!0};