//CREATE BY REZA DEVS KUROMI
let axios = require("axios"),
    FormData = require("form-data"),
    { fromBuffer } = require("file-type");

exports.run = {
  usage: ["setcover"],
  hidden: ["cover"],
  use: "reply photo",
  category: "owner",
  async: async (e, { func: t, kuromi: a, setting: r, quoted: o }) => {
    if (/image/.test(o.mime)) {
      let i = await o.download();
      if (!i) return e.reply("Gagal mengunduh gambar.");

      let { ext, mime } = (await fromBuffer(i)) || {};
      let form = new FormData();
      form.append("file", i, { filename: "cover." + ext, contentType: mime });

      try {
        let res = await axios.post("https://cdn.nkhm.xyz/upload", form, {
          headers: {
            ...form.getHeaders(),
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36",
            Referer: "https://cdn.nkhm.xyz/"
          }
        });

        let url = res.data?.files?.[0]?.url;
        if (!url) return e.reply("Gagal mendapatkan link gambar.");
        r.cover = url;
        a.reply(e.chat, t.texted("bold", "Cover successfully set."), e);
      } catch (err) {
        console.error(err);
        e.reply("Terjadi kesalahan saat upload ke cdn.nkhm.xyz.");
      }
    } else {
      e.reply("Image not found.");
    }
  },
  owner: !0
};