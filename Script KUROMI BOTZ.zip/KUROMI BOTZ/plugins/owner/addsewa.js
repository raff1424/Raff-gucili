//CREATE BY REZA DEVS KUROMI
let toMs=require("ms"),getBinaryNodeChild=require("@whiskeysockets/baileys").getBinaryNodeChild;exports.run={usage:["addsewa","delsewa"],use:"parameter",category:"owner",async:async(t,{func:s,kuromi:r,errorMessage:e})=>{async function i(e){try{var a,t,[,s]=e.match(/chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i)||[];return s?(a=await r.query({tag:"iq",attrs:{type:"get",xmlns:"w:g2",to:"@g.us"},content:[{tag:"invite",attrs:{code:s}}]}),{status:!0,code:s,groupId:(t=getBinaryNodeChild(a,"group"))?.attrs?.id.includes("@")?t?.attrs?.id:t?.attrs?.id+"@g.us"}):{status:!1,message:"No invite url detected."}}catch(e){return{status:!1,message:e.message}}}switch(t.command){case"addsewa":var[p,d]=t.args;if(/^\d.*(@g\.us)$/.test(t.chat)){var u=global.db.groups[t.chat];if(void 0===u)return t.reply("Group data not found.");if(/^(vip)$/i.test(p)){if(u&&u.sewa&&!u.sewa.status)return t.reply("Grup ini tidak ada di data sewa.");if(u&&u.sewa&&u.sewa.status&&u.sewa.vip)return t.reply("Already rented VIP!");u.sewa.vip=!0,r.reply(t.chat,"Successfully added rent `VIP` to this group.",t,{expiration:t.expiration})}else{var o=p?Date.now()+toMs(p):1/0;if(u&&u.sewa&&u.sewa.status)return t.reply("Grup tersebut sudah ada di data sewa.");u.sewa.status=!0,u.sewa.notice=!0,u.sewa.expired=o,r.reply(t.chat,"Successfully added rent to this group for "+(p||"30d"),t,{expiration:t.expiration})}}else if(/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+/.test(p)){if(!(u=await i(p)).status)return t.reply(u.message);let a=u.groupId;if(void 0===(o=global.db.groups[a]))return t.reply("Group data not found.");if(/^(vip)$/i.test(d)){if(o&&o.sewa&&!o.sewa.status)return t.reply("Grup ini tidak ada di data sewa.");if(o&&o.sewa&&o.sewa.status&&o.sewa.vip)return t.reply("Already rented VIP!");o.sewa.vip=!0,r.reply(t.chat,"Successfully added rent `VIP` to this group.",t,{expiration:t.expiration}).then(async()=>{r.reply(a,"This group successfully rented bot `VIP`.",s.fverified,{expiration:t.expiration})})}else{if(p=u.code,o=await r.groupFetchAllParticipating(),!Object.values(o).map(e=>e.id).includes(a))try{await r.groupAcceptInvite(p)}catch{}try{let e=d||"30d";var n=d?Date.now()+toMs(d):1/0,l=(w=a,"object"!=typeof(c=global.db.groups[w])&&(global.db.groups[w]={}),Object.assign(c,{jid:w,sewa:{status:!0,notice:!0,vip:!1,expired:0}}),c);if(void 0===l)return t.reply("Group data not found.");if(l.sewa&&l.sewa.status)return t.reply("Grup tersebut sudah ada di data sewa.");l.sewa.status=!0,l.sewa.notice=!0,l.sewa.expired=n,r.reply(t.chat,"Successfully added rent to this group for "+e,t,{expiration:t.expiration}).then(async()=>{r.reply(a,"This group successfully rented bot for "+e,s.fverified,{expiration:t.expiration})})}catch(i){return String(i).includes("not-authorized")?t.reply("Masukkan bot kedalam grup tersebut terlebih dahulu."):e(i)}}}else u=`Contoh penggunaan:


*in private chat*:
- ${t.prefix}addsewa <link grup> vip
_bot akan disewa \`VIP\` oleh grup tersebut_.
- addsewa <link grup> 30d
_bot akan disewa selama 30 day oleh grup tersebut_.

*in group chat*:
- ${t.prefix}addsewa vip
_bot akan disewa \`VIP\` oleh grup ini.
- ${t.prefix}addsewa 30d
_bot akan disewa selama 30 day oleh grup ini_.`,r.reply(t.chat,u,t,{expiration:t.expiration});break;case"delsewa":var[o,p]=t.args;return/^\d.*(@g\.us)$/.test(t.chat)?void 0===(d=global.db.groups[t.chat])?t.reply("Group data not found."):/^(vip)$/i.test(o)?d&&d.sewa&&!d.sewa.status?t.reply("Grup ini tidak ada di data sewa."):d&&d.sewa&&!d.sewa.vip?t.reply("VIP data not found."):(d.sewa.vip=!1,void r.reply(t.chat,"Successfully deleted rent `VIP` to this group.",t,{expiration:t.expiration})):d&&d.sewa&&!d.sewa.status?t.reply("Grup ini tidak ada di data sewa."):(d.sewa.expired=0,d.sewa.status=!1,d.sewa.notice=!1,d.sewa.vip=!1,void r.reply(t.chat,"Successfully deleted rent to this group.",t,{expiration:t.expiration})):/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+/.test(o)?(w=await i(o)).status?void 0===(c=global.db.groups[w.groupId])?t.reply("Group data not found."):/^(vip)$/i.test(p)?c&&c.sewa&&!c.sewa.status?t.reply("Grup tersebut tidak ada di data sewa."):c&&c.sewa&&!c.sewa.vip?t.reply("VIP data not found."):(c.sewa.vip=!1,void r.reply(t.chat,"Successfully deleted rent `VIP` to this group.",t,{expiration:t.expiration})):c&&c.sewa&&!c.sewa.status?t.reply("Grup tersebut tidak ada di data sewa."):(c.sewa.expired=0,c.sewa.status=!1,c.sewa.notice=!1,void r.reply(t.chat,"Successfully deleted rent to this group.",t,{expiration:t.expiration})):t.reply(w.message):(l=`Contoh penggunaan:


*in private chat*:
- ${t.prefix}delsewa <link grup> vip
_menghapus status sewabot \`VIP\` pada grup tersebut_.
- ${t.prefix}delsewa <link grup>
_menghapus status sewabot pada grup tersebut_.

*in group chat*:
- ${t.prefix}delsewa vip
_menghapus status sewabot \`VIP\` pada grup ini.
- ${t.prefix}delsewa
_menghapus status sewabot pada grup ini_.`,void r.reply(t.chat,l,t,{expiration:t.expiration}))}var w,c},owner:!0,location:"plugins/owner/addsewa.js"};