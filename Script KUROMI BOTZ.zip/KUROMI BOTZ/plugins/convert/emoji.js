exports.run = {
  usage: ['emoji'],
  hidden: [''],
  use: 'emoji',
  category: 'convert',
  async: async (m, { func, kuromi, packname, author }) => {
    let text;
    if (m.args.length >= 1) {
      text = m.args.slice(0).join(' ');
    } else if (m.quoted && m.quoted.text) {
      text = m.quoted.text;
    } else return m.reply('Input atau reply emoji!');

    if (!text) return m.reply(func.example(m.cmd, '😋'));

    kuromi.sendReact(m.chat, '🕒', m.key);

    try {
      let res = await fetch(`https://api.neoxr.eu/api/emojito?q=${encodeURIComponent(text)}&apikey=2uWbOm`);
      let json = await res.json();
      if (!json.status || !json.data?.url) return m.reply('Gagal mengambil emoji!');

      await kuromi.sendStickerFromUrl(m.chat, json.data.url, m, {
        packname: packname,
        author: author,
        expiration: m.expiration
      });
    } catch (e) {
      m.reply('Terjadi kesalahan!');
    }
  },
  limit: 10
}