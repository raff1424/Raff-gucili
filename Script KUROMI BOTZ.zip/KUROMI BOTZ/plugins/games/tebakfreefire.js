//CREATE BY REZA DEVS KUROMI
let fetch = require("node-fetch"),
similarity = require("similarity"),
sensitive = 0.75,
database = {},
player = 0;

exports.run = {
  usage: ["tebakfreefire"],
  hidden: ["tff"],
  category: "games",
  async: async (m, { func, kuromi, setting }) => {
    if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit);
    if (m.chat in database) return kuromi.reply(m.chat, "Masih ada soal belum terjawab di chat ini", database[m.chat].chat);

    let res = await fetch("https://api.siputzx.my.id/api/games/karakter-freefire");
    let json = await res.json();
    let data = json.data;
    let reward = func.hadiah(setting.hadiah);
    let time = Date.now();

    // Clue logic yang diperbaiki
    let name = data.name;
    let clue = name.length > 3 ? name.slice(0, 3) + "*".repeat(name.length - 3) : name.slice(0, 1) + "*".repeat(name.length - 1);

    let caption = `G A M E - T E B A K  F R E E  F I R E

Tebak nama karakter FF dari gambar berikut!
Clue: *${clue}*
Hadiah: $${reward} balance
Waktu: ${setting.gamewaktu} detik`;

    player = 0;
    database[m.chat] = {
      id: time,
      chat: await kuromi.sendMessage(m.chat, {
        image: { url: data.gambar },
        caption
      }, { quoted: m }),
      soal: data.name,
      jawaban: data.name.toLowerCase(),
      hadiah: reward,
      salah: 0,
      waktu: setTimeout(() => {
        if (database[m.chat]?.id == time) {
          kuromi.sendMessage(m.chat, {
            text: `Waktu habis!\n\nJawabannya adalah: ${func.texted("monospace", data.name)}`
          }, { quoted: database[m.chat].chat });
          delete database[m.chat];
        }
      }, 1000 * setting.gamewaktu)
    };
  },

  main: async (m, { func, kuromi, setting }) => {
    if (m.chat in database && !m.fromMe && !m.isPrefix) {
      let db = database[m.chat];
      if (similarity(db.jawaban, m.budy.toLowerCase()) >= sensitive) {
        player++;
        kuromi.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        global.db.users[m.sender].balance += db.hadiah;
        global.db.users[m.sender].game.tebakfreefire = (global.db.users[m.sender].game.tebakfreefire || 0) + 1;
        clearTimeout(db.waktu);
        delete database[m.chat];

        // Auto next soal
        setTimeout(async () => {
          if (player > 1) return;
          if (global.db.users[m.sender].limit < 1) return m.reply("Soal dihentikan karena limit kamu sudah habis.");
          --global.db.users[m.sender].limit;

          let res = await fetch("https://api.siputzx.my.id/api/games/karakter-freefire");
          let json = await res.json();
          let data = json.data;
          let reward = func.hadiah(setting.hadiah);
          let time = Date.now();
          let name = data.name;
          let clue = name.length > 3 ? name.slice(0, 3) + "*".repeat(name.length - 3) : name.slice(0, 1) + "*".repeat(name.length - 1);

          let caption = `LANJUT SOAL BERIKUTNYA

Tebak nama karakter FF dari gambar berikut!
Clue: *${clue}*
Hadiah: $${reward} balance
Waktu: ${setting.gamewaktu} detik`;

          player = 0;
          database[m.chat] = {
            id: time,
            chat: await kuromi.sendMessage(m.chat, {
              image: { url: data.gambar },
              caption
            }, { quoted: m }),
            soal: data.name,
            jawaban: data.name.toLowerCase(),
            hadiah: reward,
            salah: 0,
            waktu: setTimeout(() => {
              if (database[m.chat]?.id == time) {
                kuromi.sendMessage(m.chat, {
                  text: `Waktu habis!\n\nJawabannya adalah: ${func.texted("monospace", data.name)}`
                }, { quoted: database[m.chat].chat });
                delete database[m.chat];
              }
            }, 1000 * setting.gamewaktu)
          };
        }, 1000);
      } else {
        db.salah++;
        await kuromi.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        if (db.salah >= 3) {
          clearTimeout(db.waktu);
          kuromi.sendMessage(m.chat, {
            text: `Kesempatan habis setelah 3 jawaban salah!\n\nJawabannya adalah: ${func.texted("monospace", db.jawaban)}`
          }, { quoted: db.chat });
          delete database[m.chat];
        }
      }
    }
  }
};