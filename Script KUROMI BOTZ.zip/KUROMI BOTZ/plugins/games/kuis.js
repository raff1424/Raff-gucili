const similarity = require('similarity');
const gamesUrl = 'https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/kuis.json';
const sensitive = 0.75;
let keyId = {};
let alreadyAnswered = new Set();

exports.run = {
    usage: ['kuis'],
    category: 'games',
    async: async (m, {
        func,
        kuromi,
        setting,
        users
    }) => {
        kuromi.kuis = kuromi.kuis || {};
        if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
        if (m.chat in kuromi.kuis) return kuromi.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', keyId[m.chat], {
            expiration: m.expiration
        });
        let data = await fetch(gamesUrl).then(response => response.json());
        let {
            soal,
            jawaban
        } = data.result.random();
        let hadiah = func.hadiah(setting.hadiah);
        let id = Date.now();
        alreadyAnswered.clear();
        let caption = `乂 *GAMES KUIS*\n\n${func.texted('monospace', soal)}\n${users.premium ? '\nPetunjuk: ' + func.createClue(jawaban) : ''}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`
        keyId[m.chat] = await kuromi.reply(m.chat, caption, m, {
            expiration: m.expiration
        });
        kuromi.kuis[m.chat] = {
            id: id,
            soal: soal,
            jawaban: jawaban.toLowerCase(),
            hadiah: hadiah,
            nextQuestion: 1,
            timeout: setTimeout(async function() {
                let gameData = kuromi.kuis[m.chat];
                if (gameData.id == id) {
                    kuromi.reply(m.chat, `Waktu habis!\n\nJawabannya adalah: ${func.texted('monospace', jawaban)}`, keyId[m.chat], {
                        expiration: m.expiration
                    }).then(async () => {
                        if (keyId[m.chat]) {
                            await func.delay(1500).then(async () => await kuromi.sendMessage(m.chat, {
                                delete: keyId[m.chat].key
                            }))
                        }
                    })
                    delete kuromi.kuis[m.chat];
                }
            }, setting.gamewaktu * 1000)
        }
    },
    main: async (m, {
        func,
        kuromi,
        setting,
        users
    }) => {
        // Games Kuis By SuryaDev
        kuromi.kuis = kuromi.kuis || {};
        if ((m.chat in kuromi.kuis) && !m.fromMe && !m.isPrefix) {
            let gameData = kuromi.kuis[m.chat];
            if (similarity(gameData.jawaban, m.budy.toLowerCase()) >= sensitive) {
                if (alreadyAnswered.has(gameData.jawaban)) return kuromi.sendReact(m.chat, '🥴', m.key);
                alreadyAnswered.add(gameData.jawaban);
                // await kuromi.sendReact(m.chat, '✅', m.key)
                users.balance += gameData.hadiah;
                users.game.kuis++;
                gameData.nextQuestion++;
                if (gameData.timeout) clearTimeout(gameData.timeout);
                let key;
                if (users.limit < 1) {
                    let price = setting.limit.price;
                    if (users.balance > price) {
                        users.balance -= price;
                        key = await kuromi.reply(m.chat, `Sistem otomatis mengambil \`${price} balance\` kamu sebagai pengganti limit.`, m, {
                            expiration: m.expiration
                        })
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    } else {
                        delete kuromi.susunkata[m.chat];
                        return await kuromi.reply(m.chat, 'Soal dihentikan karena limit & balance kamu sudah habis.', m, {
                            expiration: m.expiration
                        })
                    }
                } else {
                    users.limit -= 1;
                    /*if (keyId[m.chat]) await kuromi.sendMessage(m.chat, {
                        delete: keyId[m.chat].key
                    })*/
                }
                let data = await fetch(gamesUrl).then(response => response.json());
                let result = data.result.random();
                let hadiah = func.hadiah(setting.hadiah);
                let id = Date.now();
                alreadyAnswered.clear();
                let caption = `*LANJUT SOAL KE-${gameData.nextQuestion}*\n\n${func.texted('monospace', result.soal)}\n${users.premium ? '\nPetunjuk: ' + func.createClue(result.jawaban) : ''}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`
                keyId[m.chat] = await kuromi.reply(m.chat, caption, m, {
                    /*...(key ? {
                        edit: key
                    } : {}),*/
                    expiration: m.expiration
                });
                Object.assign(gameData, {
                    id: id,
                    soal: result.soal,
                    jawaban: result.jawaban.toLowerCase(),
                    hadiah: hadiah,
                    timeout: setTimeout(function() {
                        if (gameData.id == id) {
                            kuromi.reply(m.chat, `Waktu habis!\n\nJawabannya adalah: ${func.texted('monospace', result.jawaban)}`, keyId[m.chat], {
                                expiration: m.expiration
                            }).then(async () => {
                                if (keyId[m.chat]) {
                                    await func.delay(1500).then(async () => await kuromi.sendMessage(m.chat, {
                                        delete: keyId[m.chat].key
                                    }))
                                }
                            })
                            delete kuromi.kuis[m.chat];
                        }
                    }, setting.gamewaktu * 1000)
                })
                if (kuromi.kuis[m.chat]) return false;
            } else if (/conversation|extendedTextMessage/.test(m.mtype) && setting.incorrect) {
                await kuromi.sendReact(m.chat, '❌', m.key)
            }
        }
    },
    location: 'plugins/games/kuis.js'
}