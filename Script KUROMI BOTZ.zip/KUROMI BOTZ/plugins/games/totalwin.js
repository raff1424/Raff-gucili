//CREATE BY REZA DEVS KUROMI
exports.run={usage:["totalwin"],hidden:["totalmenang"],category:"games",async:async(e,{func:t,kuromi:a})=>{var n=global.db.users[e.sender].game,r=Object.values(n).reduce((e,a)=>e+a,0);if(0===r)return e.reply("Data kosong.");n=`乂 *LIST TOTAL WIN GAMES*

`+Object.entries(n).filter(([,e])=>0<e).map(([e,a])=>`- ${t.ucword(e)} : ${a}
`).join("")+`
Total : *${r}*`,a.reply(e.chat,n,e,{expiration:e.expiration})},location:"plugins/games/totalwin.js"};