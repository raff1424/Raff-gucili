//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch");exports.run={usage:["spin"],use:"jumlah",category:"games",async:async(e,{func:a,kuromi:t,users:n,setting:r})=>{if("lastSpin"in n||(n.lastSpin=0),!e.text||!/^\d+$/.test(e.text))return e.reply(a.example(e.cmd,"1000"));if(a=parseInt(e.text),n.balance<a)return e.reply("Balance Anda tidak mencukupi.");var i=.5<=Math.random(),l=i?Math.ceil(1.31919*a):-a;if(n.balance+=l,n.lastSpin&&Number(new Date)-n.lastSpin<1e4)return s=Math.ceil((n.lastSpin+1e4-Number(new Date))/1e3),e.reply(`Harap tunggu ${s} detik sebelum menjalankan putaran berikutnya.`);n.lastSpin=Number(new Date);var s=`*🧐 Let's See the Results*

`,s=(s=(s+=`*- ${a.toLocaleString()}*
`)+(i?`*+ ${l.toLocaleString()}*

`:`

`))+`• Total : *${n.balance.toLocaleString()}* Balance`;t.sendMessageModify(e.chat,s,e,{title:global.header,body:"S P I N - R E S U L T",thumbnail:await(await fetch(r.cover)).buffer(),largeThumb:!0,expiration:e.expiration})},limit:!0};