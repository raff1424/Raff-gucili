//CREATE BY REZA DEVS KUROMI
exports.run={usage:["cowboy"],hidden:["coboy"],use:"options",category:"games",async:async(o,{func:t,kuromi:i})=>{var s,c;return i.cowboy=i.cowboy||{musuh:[],shoot:[]},/left/i.test(o.text)?(c=[["🤠","・","・","・","・"],["・","🤠","・","・","・"],["・","・","🤠","・","・"],["・","・","・","🤠","・"],["・","・","・","・","🤠"]],0==i.cowboy.shoot.indexOf("🤠")||1==i.cowboy.shoot.indexOf("🤠")?i.cowboy.shoot=c[0]:2==i.cowboy.shoot.indexOf("🤠")?i.cowboy.shoot=c[1]:3==i.cowboy.shoot.indexOf("🤠")?i.cowboy.shoot=c[2]:4==i.cowboy.shoot.indexOf("🤠")&&(i.cowboy.shoot=c[3]),c=`🤠 Cowboy Chasing Criminals 🥷

`,c=(c=(c+=`Your territory:
${i.cowboy.shoot.join(" ")}
`)+`Criminals terriroty:
${i.cowboy.musuh.join(" ")}
`)+`Example : ${o.cmd} right or ${o.cmd} left for move to right/left and ${o.cmd} shoot to shoot`,i.cowboy.musuh.indexOf("🥷"),i.cowboy.shoot.indexOf("🤠"),o.reply(c)):/right/i.test(o.text)?(c=[["🤠","・","・","・","・"],["・","🤠","・","・","・"],["・","・","🤠","・","・"],["・","・","・","🤠","・"],["・","・","・","・","🤠"]],0==i.cowboy.shoot.indexOf("🤠")?i.cowboy.shoot=c[1]:1==i.cowboy.shoot.indexOf("🤠")?i.cowboy.shoot=c[2]:2==i.cowboy.shoot.indexOf("🤠")?i.cowboy.shoot=c[3]:3!=i.cowboy.shoot.indexOf("🤠")&&4!=i.cowboy.shoot.indexOf("🤠")||(i.cowboy.shoot=c[4]),c=`🤠 Cowboy Chacing Criminals 🥷

`,c=(c=(c+=`Your territory:
${i.cowboy.shoot.join(" ")}
`)+`Criminals terriroty:
${i.cowboy.musuh.join(" ")}
`)+`Example : ${o.cmd} right or ${o.cmd} left for move to right/left and ${o.cmd} shoot to shoot`,i.cowboy.musuh.indexOf("🥷"),i.cowboy.shoot.indexOf("🤠"),o.reply(c)):/shoot/i.test(o.text)?void(i.cowboy.shoot.indexOf("🤠")==i.cowboy.musuh.indexOf("🥷")&&(i.cowboy={},o.reply("🎉 Congratulations! you succeeded in chasing the criminals! 🎉"))):(c=[["🤠","・","・","・","・"],["・","🤠","・","・","・"],["・","・","🤠","・","・"],["・","・","・","🤠","・"],["・","・","・","・","🤠"]],s=t.pickRandom([["🥷","・","・","・","・"],["・","🥷","・","・","・"],["・","・","🥷","・","・"],["・","・","・","🥷","・"],["・","・","・","・","🥷"]]),t=t.pickRandom(c),i.cowboy.musuh=s,i.cowboy.shoot=t,c=`🤠 Cowboy Chasing Criminals 🥷

`,c=(c=(c+=`Your territory:
${i.cowboy.shoot.join(" ")}
`)+`Criminals terriroty:
${i.cowboy.musuh.join(" ")}
`)+`Example : ${o.cmd} right or ${o.cmd} left for move to right/left and ${o.cmd} shoot to shoot`,i.cowboy.musuh.indexOf("🥷"),i.cowboy.shoot.indexOf("🤠"),o.reply(c))},limit:!0};