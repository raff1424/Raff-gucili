//CREATE BY REZA DEVS KUROMI
let similarity=require("similarity"),gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/caklontong.json",sensitive=.75,database={},player=0;exports.run={usage:["caklontong"],category:"games",async:async(a,{func:e,kuromi:t,setting:i,users:s})=>{if(e.ceklimit(a.sender,1))return a.reply(global.mess.limit);if(a.chat in database)return t.reply(a.chat,"Masih ada soal belum terjawab di chat ini",database[a.chat].chat);let{soal:n,jawaban:r}=(await fetch(gamesUrl).then(a=>a.json())).result.random(),c=e.hadiah(i.hadiah),o=Date.now();s=`*G A M E - C A K L O N T O N G*

${e.texted("monospace",n)}
${s.premium?"\nPetunjuk: "+e.texted("monospace",r.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi,"-")):""}
Hadiah: $${c} balance
Waktu: ${i.gamewaktu} detik`,player=0,database[a.chat]={id:o,chat:await t.reply(a.chat,s,a,{expiration:a.expiration}),soal:n,jawaban:r.toLowerCase(),hadiah:c,waktu:setTimeout(function(){database[a.chat]?.id==o&&(t.reply(a.chat,`Waktu habis!

Jawabannya adalah: `+e.texted("monospace",r),database[a.chat].chat,{expiration:a.expiration}),delete database[a.chat])},1e3*i.gamewaktu)}},main:async(s,{func:n,kuromi:r,setting:c,users:o})=>{var a,e,t,i;s.chat in database&&!s.fromMe&&!s.isPrefix&&({soal:a,jawaban:e,hadiah:t,waktu:i}=database[s.chat],similarity(e,s.budy.toLowerCase())>=sensitive?(player++,r.sendMessage(s.chat,{react:{text:"✅",key:s.key}}),o.balance+=t,o.game.caklontong+=1,clearTimeout(i),delete database[s.chat],setTimeout(async()=>{if(!(1<player)){if(o.limit<1)return s.reply("Soal dihentikan karena limit kamu sudah habis.");--o.limit;let a=(await fetch(gamesUrl).then(a=>a.json())).result.random(),e=n.hadiah(c.hadiah),t=Date.now(),i=`*LANJUT SOAL BERIKUTNYA*

${n.texted("monospace",a.soal)}
${o.premium?"\nPetunjuk: "+n.texted("monospace",a.jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi,"-")):""}
Hadiah: $${e} balance
Waktu: ${c.gamewaktu} detik`;player=0,database[s.chat]={id:t,chat:await r.reply(s.chat,i,s,{expiration:s.expiration}),soal:a.soal,jawaban:a.jawaban.toLowerCase(),hadiah:e,waktu:setTimeout(function(){database[s.chat]?.id==t&&(r.reply(s.chat,`Waktu habis!

Jawabannya adalah: `+n.texted("monospace",a.jawaban),database[s.chat].chat,{expiration:s.expiration}),delete database[s.chat])},1e3*c.gamewaktu)}}},1e3)):/conversation|extendedTextMessage/.test(s.mtype)&&await r.sendMessage(s.chat,{react:{text:"❌",key:s.key}}))}};