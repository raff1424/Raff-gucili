//CREATE BY REZA DEVS KUROMI
exports.run={usage:["buylimit"],use:"jumlah",category:"games",async:async(e,{func:a,setting:s,isPrem:l})=>{var r;return e.text?(r=(e.args[0]||"").replace(/-/g,""),isNaN(r)?e.reply(`Jumlah harus berupa angka!
Contoh: ${e.cmd} 1`):(l=l?500:1e6<=global.db.users[e.sender].balance?1500:s.limit.price,s=Number(parseInt(r)*l),global.db.users[e.sender].balance<s?e.reply("Balance kamu tidak mencukupi untuk pembelian ini!"):(global.db.users[e.sender].limit+=parseInt(r),global.db.users[e.sender].balance-=s,void e.reply(`Membeli *${r} limit* seharga *${a.rupiah(s)} balance*
> sisa balance: ${a.rupiah(global.db.users[e.sender].balance)}
> sisa limit: `+global.db.users[e.sender].limit)))):e.reply(`Input jumlahnya!
Contoh: ${e.cmd} 1`)}};