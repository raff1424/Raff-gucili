//CREATE BY REZA DEVS KUROMI
let fetch = require("node-fetch"),
similarity = require("similarity"),
sensitive = 0.75,
database = {},
player = 0;

exports.run = {
  usage: ["tebakjenaka"],
  hidden: ["tjenaka"],
  category: "games",
  async: async (a, { func: e, kuromi: t, setting: s, isPrem: i }) => {
    if (e.ceklimit(a.sender, 1)) return a.reply(global.mess.limit);
    if (a.chat in database) return t.reply(a.chat, "Masih ada soal belum terjawab di chat ini", database[a.chat].chat);

    let res = await fetch("https://api.lolhuman.xyz/api/tebak/jenaka?apikey=kuromi");
    let json = await res.json();
    let n = json.result.question;
    let d = json.result.answer;
    let r = e.hadiah(s.hadiah);
    let h = Date.now();

    i = `G A M E - T E B A K J E N A K A

${e.texted("monospace", n)}
${i ? "\nPetunjuk: " + e.texted("monospace", d.replace(/[b-df-hj-np-tv-z]/gi, "-")) : ""}
Hadiah: $${r} balance
Waktu: ${s.gamewaktu} detik`;

    player = 0;
    database[a.chat] = {
      id: h,
      chat: await t.sendMessage(a.chat, { text: i }, { quoted: a, ephemeralExpiration: a.expiration }),
      soal: n,
      jawaban: d.toLowerCase(),
      hadiah: r,
      waktu: setTimeout(async function () {
        if (database[a.chat]?.id == h) {
          t.sendMessage(a.chat, { text: `Waktu habis!\n\nJawabannya adalah: ` + e.texted("monospace", d) }, { quoted: database[a.chat].chat, ephemeralExpiration: a.expiration });
          delete database[a.chat];
        }
      }, 1e3 * s.gamewaktu)
    };
  },

  main: async (n, { func: d, kuromi: r, setting: h }) => {
    var a, e, t, s;
    if (n.chat in database && !n.fromMe && !n.isPrefix) {
      ({ soal: a, jawaban: e, hadiah: t, waktu: s } = database[n.chat]);
      if (similarity(e, n.budy.toLowerCase()) >= sensitive) {
        player++;
        r.sendMessage(n.chat, { react: { text: "✅", key: n.key } });
        global.db.users[n.sender].balance += t;
        global.db.users[n.sender].game.tebakjenaka = (global.db.users[n.sender].game.tebakjenaka || 0) + 1;
        clearTimeout(s);
        delete database[n.chat];
        setTimeout(async () => {
          if (player > 1) return;
          if (global.db.users[n.sender].limit < 1) return n.reply("Soal dihentikan karena limit kamu sudah habis.");
          --global.db.users[n.sender].limit;

          let res = await fetch("https://api.lolhuman.xyz/api/tebak/jenaka?apikey=kuromi");
          let json = await res.json();
          let a = json.result.question;
          let e = json.result.answer;
          let t = d.hadiah(h.hadiah);
          let s = Date.now();
          let i = `LANJUT SOAL BERIKUTNYA

${d.texted("monospace", a)}
${global.db.users[n.sender].premium ? "\nPetunjuk: " + d.texted("monospace", e.replace(/[b-df-hj-np-tv-z]/gi, "-")) : ""}
Hadiah: $${t} balance
Waktu: ${h.gamewaktu} detik`;

          player = 0;
          database[n.chat] = {
            id: s,
            chat: await r.sendMessage(n.chat, { text: i }, { quoted: n, ephemeralExpiration: n.expiration }),
            soal: a,
            jawaban: e.toLowerCase(),
            hadiah: t,
            waktu: setTimeout(async function () {
              if (database[n.chat]?.id == s) {
                r.sendMessage(n.chat, { text: `Waktu habis!\n\nJawabannya adalah: ` + d.texted("monospace", e) }, { quoted: database[n.chat].chat, ephemeralExpiration: n.expiration });
                delete database[n.chat];
              }
            }, 1e3 * h.gamewaktu)
          };
        }, 1e3);
      } else if (/conversation|extendedTextMessage/.test(n.mtype)) {
        await r.sendMessage(n.chat, { react: { text: "❌", key: n.key } });
      }
    }
  }
};