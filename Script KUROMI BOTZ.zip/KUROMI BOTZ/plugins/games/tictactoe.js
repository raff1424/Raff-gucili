//CREATE BY REZA DEVS KUROMI
exports.run={usage:["tictactoe"],hidden:["ttt"],use:"mention or reply",category:"games",async:async(t,{func:a,kuromi:n,froms:e})=>{var i;return t.isGc?Object.values(global.db.tictactoe).find(a=>a.id.startsWith("tictactoe")&&[a.penantang,a.ditantang].includes(t.sender))?t.reply("Selesaikan tictactoe mu yang sebelumnya!"):t.quoted||t.text?e?e===t.bot?t.reply("Tidak bisa bermain dengan bot!"):e===t.sender?t.reply("Sad amat main ama diri sendiri"):a.ceklimit(t.sender,1)?t.reply(global.mess.limit):(a=a.randomNomor(3e3,5e3),i="tictactoe_"+Date.now(),n.reply(t.chat,`@${t.sender.split("@")[0]} menantang @${e.split("@")[0]} untuk bermain TicTacToe

*Kirim (Y/N)* untuk bermain

Hadiah : ${a} balance`,t),void(global.db.tictactoe[i]={id:i,status:"WAIT",hadiah:a,asal:t.chat,penantang:t.sender,ditantang:e,TicTacToe:["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"]})):t.reply("Invalid number."):void t.reply("Mention or Reply chat target."):t.reply(global.mess.group)},main:async(t,{kuromi:a,fkon:n,errorMessage:e})=>{var i=a=>{let t=!0;for(var n of a)"❌"!==n&&"⭕"!==n&&(t=!1);return t},$=(a,t)=>"❌"===t[a]||"⭕"===t[a],l=a=>"❌"===a[0]&&"❌"===a[1]&&"❌"===a[2]||"⭕"===a[0]&&"⭕"===a[1]&&"⭕"===a[2]||"❌"===a[3]&&"❌"===a[4]&&"❌"===a[5]||"⭕"===a[3]&&"⭕"===a[4]&&"⭕"===a[5]||"❌"===a[6]&&"❌"===a[7]&&"❌"===a[8]||"⭕"===a[6]&&"⭕"===a[7]&&"⭕"===a[8]||"❌"===a[0]&&"❌"===a[3]&&"❌"===a[6]||"⭕"===a[0]&&"⭕"===a[3]&&"⭕"===a[6]||"❌"===a[1]&&"❌"===a[4]&&"❌"===a[7]||"⭕"===a[1]&&"⭕"===a[4]&&"⭕"===a[7]||"❌"===a[2]&&"❌"===a[5]&&"❌"===a[8]||"⭕"===a[2]&&"⭕"===a[5]&&"⭕"===a[8]||"❌"===a[0]&&"❌"===a[4]&&"❌"===a[8]||"⭕"===a[0]&&"⭕"===a[4]&&"⭕"===a[8]||"❌"===a[2]&&"❌"===a[4]&&"❌"===a[6]||"⭕"===a[2]&&"⭕"===a[4]&&"⭕"===a[6];try{var s=Object.values(global.db.tictactoe).find(a=>a.id.startsWith("tictactoe")&&[a.penantang,a.ditantang].includes(t.sender));if(s){var r,d,g,p,c=[1,2,3,4,5,6,7,8,9],o=s.TicTacToe;if(t.sender===s.ditantang&&t.isGc&&"WAIT"===s.status)if("y"===t.budy.toLowerCase())await a.reply(t.chat,`Tictactoe telah dikirimkan ke chat

@${s.penantang.split("@")[0]} dan @${s.ditantang.split("@")[0]}

Silahkan selesaikan tictactoe di chat masing²
klik wa.me/`+t.bot.split("@")[0],n),a.reply(s.penantang,`Giliran kamu mengisi

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    `+o[6]+o[7]+o[8]),a.reply(s.ditantang,`Menunggu lawan mengisi

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    ${o[6]}${o[7]}${o[8]}
    
_Giliran Lawan_`),s.status=!0;else if("n"===t.budy.toLowerCase())return t.reply(`@${s.ditantang.split("@")[0]} menolak, game dibatalkan`,[s.ditantang],!1),delete global.db.tictactoe[s.id],!0;if(t.isPc&&1==s.status){if(t.chat===s.penantang)for(var b of c)if(Number(t.budy)===b){if($(Number(t.budy)-1,o))return a.reply(s.penantang,"Nomor tersebut sudah terisi",t);s.TicTacToe[Number(t.budy)-1]="❌",l(s.TicTacToe)?(r=`Game tictactoe sudah selesai

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    `+o[6]+o[7]+o[8],a.reply(s.penantang,r,n),a.reply(s.ditantang,r,n),a.reply(s.asal,`@${s.penantang.split("@")[0]} Menang

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    ${o[6]}${o[7]}${o[8]}

Hadiah : ${s.hadiah} balance
Ingin bermain lagi? ${t.prefix}tictactoe`,n),global.db.users[s.penantang].balance+=s.hadiah,global.db.users[s.ditantang].balance-=s.hadiah,global.db.users[s.penantang].game.tictactoe+=1,delete global.db.tictactoe[s.id]):i(o)?(d=`Game tictactoe sudah selesai

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    `+o[6]+o[7]+o[8],a.reply(s.penantang,d,n),a.reply(s.ditantang,d,n),a.reply(s.asal,`乂  *H A S I L - S E R I*

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    ${o[6]}${o[7]}${o[8]}

Ingin bermain lagi? ${t.prefix}tictactoe`,n),delete global.db.tictactoe[s.id]):(a.reply(s.penantang,`Kamu sudah mengisi

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    ${o[6]}${o[7]}${o[8]}

_Giliran Lawan_`,n),a.reply(s.ditantang,`Lawan sudah mengisi

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    ${o[6]}${o[7]}${o[8]}

_Giliran Kamu_`,n),s.status=!1)}}else if(t.isPc&&0==s.status&&t.chat===s.ditantang)for(var u of c)if(Number(t.budy)===u){if($(Number(t.budy)-1,o))return a.reply(s.ditantang,"Nomor tersebut sudah terisi",t);s.TicTacToe[Number(t.budy)-1]="⭕",l(o)?(g=`Game tictactoe sudah selesai

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    `+o[6]+o[7]+o[8],a.reply(s.penantang,g,n),a.reply(s.ditantang,g,n),a.reply(s.asal,`@${s.ditantang.split("@")[0]} Menang

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    ${o[6]}${o[7]}${o[8]}

Hadiah : ${s.hadiah} balance
Ingin bermain lagi? ${t.prefix}tictactoe`,n),global.db.users[s.ditantang].balance+=s.hadiah,global.db.users[s.penantang].balance-=s.hadiah,global.db.users[s.ditantang].game.tictactoe+=1,delete global.db.tictactoe[s.id]):i(o)?(p=`Game tictactoe sudah selesai

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    `+o[6]+o[7]+o[8],a.reply(s.penantang,p,n),a.reply(s.ditantang,p,n),a.reply(s.asal,`乂  *H A S I L - S E R I*

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    ${o[6]}${o[7]}${o[8]}

Ingin bermain lagi? ${t.prefix}tictactoe`,n),delete global.db.tictactoe[s.id]):(a.reply(s.ditantang,`Kamu sudah mengisi

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    ${o[6]}${o[7]}${o[8]}

_Giliran Lawan_`,n),a.reply(s.penantang,`Lawan sudah mengisi

@${s.penantang.split("@")[0]} = ❌
@${s.ditantang.split("@")[0]} = ⭕

    ${o[0]}${o[1]}${o[2]}
    ${o[3]}${o[4]}${o[5]}
    ${o[6]}${o[7]}${o[8]}

_Giliran Kamu_`,n),s.status=!0)}}}catch(a){return e(a)}}};