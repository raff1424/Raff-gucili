//CREATE BY REZA DEVS KUROMI
function getWinningMove(t,i){var n;for(n of[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]){let e=0,a=-1;for(var r of n)t[r]===i?e++:"❌"!==t[r]&&"⭕"!==t[r]&&(a=r);if(2===e&&-1!==a)return a}return-1}function displayBoard(e){var a="    ";return a+e[0]+e[1]+e[2]+`
${a+e[3]+e[4]+e[5]}
`+a+e[6]+e[7]+e[8]}function delay(a){return new Promise(e=>setTimeout(e,a))}exports.run={usage:["tbot"],hidden:["ttt-bot"],use:"mention or reply",category:"games",async:async(e,{func:a,kuromi:t})=>{var i;return t.tictactoe=t.tictactoe||{},e.sender in t.tictactoe?t.reply(e.chat,"Masih ada game yang belum selesai",t.tictactoe[e.sender].key,{expiration:e.expiration}):a.ceklimit(e.sender,1)?e.reply(global.mess.limit):(a=a.randomNomor(3e3,5e3),Date.now(),i=await t.reply(e.chat,`@${e.sender.split("@")[0]} menantang bot untuk bermain TicTacToe

*Game akan dimulai*.

Hadiah : ${a} balance`,e,{expiration:e.expiration}),t.tictactoe[e.sender]={id:e.sender,key:i,keyId:[],status:!0,hadiah:a,penantang:e.sender,ditantang:e.bot,TicTacToe:["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"]},await delay(2e3),a=t.tictactoe[e.sender],await t.reply(e.chat,`@${a.penantang.split("@")[0]} = ❌
@${a.ditantang.split("@")[0]} = ⭕

${displayBoard(a.TicTacToe)}

Giliran @`+a.penantang.split("@")[0],e,{edit:i,expiration:e.expiration}),void a.keyId.push(i.key))},main:async(a,{kuromi:t,func:i})=>{t.tictactoe=t.tictactoe||{};var e,n=e=>{let a=!0;for(var t of e)"❌"!==t&&"⭕"!==t&&(a=!1);return a},r=e=>"❌"===e[0]&&"❌"===e[1]&&"❌"===e[2]||"⭕"===e[0]&&"⭕"===e[1]&&"⭕"===e[2]||"❌"===e[3]&&"❌"===e[4]&&"❌"===e[5]||"⭕"===e[3]&&"⭕"===e[4]&&"⭕"===e[5]||"❌"===e[6]&&"❌"===e[7]&&"❌"===e[8]||"⭕"===e[6]&&"⭕"===e[7]&&"⭕"===e[8]||"❌"===e[0]&&"❌"===e[3]&&"❌"===e[6]||"⭕"===e[0]&&"⭕"===e[3]&&"⭕"===e[6]||"❌"===e[1]&&"❌"===e[4]&&"❌"===e[7]||"⭕"===e[1]&&"⭕"===e[4]&&"⭕"===e[7]||"❌"===e[2]&&"❌"===e[5]&&"❌"===e[8]||"⭕"===e[2]&&"⭕"===e[5]&&"⭕"===e[8]||"❌"===e[0]&&"❌"===e[4]&&"❌"===e[8]||"⭕"===e[0]&&"⭕"===e[4]&&"⭕"===e[8]||"❌"===e[2]&&"❌"===e[4]&&"❌"===e[6]||"⭕"===e[2]&&"⭕"===e[4]&&"⭕"===e[6];if(((a,t)=>{let i=!1;return Object.keys(t).forEach(e=>{t[e].id===a&&(i=!0)}),i})(a.sender,t.tictactoe))try{var o=t.tictactoe[a.sender],s=o.TicTacToe;if(!0===o.status&&a.sender===o.penantang)for(var c of[1,2,3,4,5,6,7,8,9])if(Number(a.budy)===c){if("❌"===s[e=Number(a.budy)-1]||"⭕"===s[e])return a.reply("Nomor tersebut sudah terisi");t.tictactoe[a.sender].TicTacToe[Number(a.budy)-1]="❌";var d=o.keyId,l=(console.log(d),g=p=l=void 0,d);if(o.ditantang,Array.isArray(l)&&0<l.length)for(var[p,g]of l.entries()){await new Promise(e=>setTimeout(e,500));try{await t.sendMessage(g.remoteJid,{delete:g})}catch(e){console.log(e)}l.splice(p,1)}if(await 0,r(t.tictactoe[a.sender].TicTacToe))t.reply(a.chat,`@${o.penantang.split("@")[0]} Menang

@${o.penantang.split("@")[0]} = ❌
@${o.ditantang.split("@")[0]} = ⭕

${displayBoard(s)}

Hadiah : ${o.hadiah} balance`,a,{expiration:a.expiration}),await t.sendReact(a.chat,"🎉",a.key),global.db.users[o.penantang].balance+=o.hadiah,global.db.users[o.penantang].game.tictactoe+=1,delete t.tictactoe[a.sender];else if(n(s))await t.reply(a.chat,`Hasil Seri!

@${o.penantang.split("@")[0]} = ❌
@${o.ditantang.split("@")[0]} = ⭕

`+displayBoard(s),null,{expiration:a.expiration}),delete t.tictactoe[a.sender];else{var y=await t.reply(a.chat,`@${o.penantang.split("@")[0]} telah mengisi

@${o.penantang.split("@")[0]} = ❌
@${o.ditantang.split("@")[0]} = ⭕

${displayBoard(s)}

Giliran @`+o.ditantang.split("@")[0],a,{expiration:a.expiration});if(o.keyId.push(y.key),o.status=!1,0==o.status){await delay(2e3);{var u=void 0,h=void 0,f=void 0,m=void 0,T=a;let e=getWinningMove(f=(h=(u=t).tictactoe[T.sender]).TicTacToe,"⭕");-1===(e=-1===(e=-1===e?getWinningMove(f,"❌"):e)&&"❌"!==f[4]&&"⭕"!==f[4]?4:e)&&(m=f.map((e,a)=>"❌"!==e&&"⭕"!==e?a:-1).filter(e=>-1!==e),e=m[Math.floor(Math.random()*m.length)]),-1!==e&&(u.tictactoe[T.sender].TicTacToe[e]="⭕",r(u.tictactoe[T.sender].TicTacToe)?(u.reply(T.chat,`Bot Menang!

@${h.penantang.split("@")[0]} = ❌
@${h.ditantang.split("@")[0]} = ⭕

`+displayBoard(f),i.fverified,{expiration:T.expiration}),delete u.tictactoe[T.sender]):n(f)?(u.reply(T.chat,`Hasil Seri!

@${h.penantang.split("@")[0]} = ❌
@${h.ditantang.split("@")[0]} = ⭕

`+displayBoard(f),i.fverified,{expiration:T.expiration}),delete u.tictactoe[T.sender]):(m=await u.reply(T.chat,`Bot telah mengisi

@${h.penantang.split("@")[0]} = ❌
@${h.ditantang.split("@")[0]} = ⭕

${displayBoard(f)}

Giliran @`+h.penantang.split("@")[0],i.fverified,{expiration:T.expiration}),h.key=m,h.status=!0,h.keyId.push(m.key)))}await 0}}}}catch(e){console.log(e),t.reply(a.chat,e.message,a,{expiration:a.expiration})}},location:"plugins/games/ttt-bot.js"};