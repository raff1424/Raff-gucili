//CREATE BY REZA DEVS KUROMI
exports.run={usage:["setleft"],use:"text",category:"admin tools",async:async(e,{func:t,kuromi:s,groups:u})=>{if(!e.text)return e.reply(t.example(e.cmd,u.teksleft+`

+user untuk tag user
+group untuk nama grup
+desc untuk deskripsi grup`));s=(t=await s.groupMetadata(e.chat)||{}).subject||"",t=t.desc||"",s=e.text.replace("+user","@"+e.sender.split("@")[0]).replace("+group",s).replace("+desc",t),u.teksleft=e.text,e.reply(`Text left successfully changed to :
`+s)},admin:!0,group:!0};