//CREATE BY REZA DEVS KUROMI
exports.run={usage:["tagall"],use:"text",category:"group",async:async(e,{func:a,kuromi:t})=>{let n=`乂  *T A G - A L L*
`+(e.text?"\nPesan: "+e.text+"\n":"");e.members.forEach(e=>{n+=`
${"superadmin"==e.admin?"👑":"admin"==e.admin?"😈":"👤"} @`+e.id.split("@")[0]}),t.sendMessage(e.chat,{text:n,mentions:e.members.map(e=>e.id)},{quoted:a.fverified,ephemeralExpiration:e.expiration})},group:!0,admin:!0};