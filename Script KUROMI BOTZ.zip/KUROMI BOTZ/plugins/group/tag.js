//CREATE BY REZA DEVS KUROMI
exports.run={usage:["tag"],category:"group",async:async(e,{kuromi:a})=>{e.text&&a.reply(e.chat,"@"+e.text.replace(/[^0-9]/gi,""),e,{expiration:e.expiration})},group:!0};