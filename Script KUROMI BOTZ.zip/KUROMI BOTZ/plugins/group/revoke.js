//CREATE BY REZA DEVS KUROMI
exports.run={usage:["revoke"],category:"group",async:async(e,{kuromi:t})=>{await t.groupRevokeInvite(e.chat).then(a=>e.reply(`Sukses menyetel ulang tautan grup!
Tautan baru: https://chat.whatsapp.com/`+a)).catch(a=>t.sendReact(e.chat,"❌",e.key))},group:!0,admin:!0,boAdmin:!0};