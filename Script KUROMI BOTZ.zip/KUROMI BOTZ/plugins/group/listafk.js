//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch");exports.run={usage:["listafk"],category:"group",async:async(a,{func:t,kuromi:e,setting:l})=>{var n=Object.values(global.db.users).filter(a=>0<a.afk);if(0==n.length)return a.reply("Data kosong.");var o=`乂  *LIST USER AFK*
Total : *${n.length}*
`;o+=n.map((a,e)=>`
${e+1}. @${a.jid.split("@")[0]}
◦  Reason: ${a.alasan??"tanpa alasan"}
◦  Selama: `+t.clockString(Date.now()-a.afk)).join("\n"),e.sendMessageModify(a.chat,o,a,{title:global.header,body:global.footer,thumbnail:await(await fetch(l.cover)).buffer(),largeThumb:!0,expiration:a.expiration})},group:!0};