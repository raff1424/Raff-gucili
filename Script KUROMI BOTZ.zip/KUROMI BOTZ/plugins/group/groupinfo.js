//CREATE BY REZA DEVS KUROMI
let moment=require("moment-timezone");exports.run={usage:["groupinfo"],hidden:["infogroup"],category:"group",async:async(e,{func:t,kuromi:a})=>{var i=global.db.groups[e.chat],n=await a.groupMetadata(e.chat),r=n.participants.filter(e=>e.admin),o=await t.fetchBuffer(await a.profilePictureUrl(e.chat,"image").catch(e=>"https://telegra.ph/file/320b066dc81928b782c7b.png")),r=`乂  *G R O U P  I N F O*

	◦  *Name* : ${n.subject}
	◦  *ID* : ${n.id}
	◦  *Owner* : ${n.owner?"@"+n.owner.split("@")[0]:e.chat.match("-")?"@"+e.chat.split("-")[0]:""}
	◦  *Created :* ${moment(1e3*n.creation).format("DD/MM/YY HH:mm:ss")}
	◦  *Member :* ${n.participants.length}
	◦  *Admin :* ${r.length}
	
乂  *M O D E R A T I O N*

	◦  *${i.welcome?"[ √ ]":"[ × ]"}* Welcome Message
	◦  *${i.left?"[ √ ]":"[ × ]"}* Leave Message
	◦  *${i.detect?"[ √ ]":"[ × ]"}* Detect Message
	◦  *${i.antitoxic?"[ √ ]":"[ × ]"}* Anti Toxic
	◦  *${i.antilink?"[ √ ]":"[ × ]"}* Anti Link
	◦  *${i.antivirtex?"[ √ ]":"[ × ]"}* Anti Virtex
	◦  *${i.antibot?"[ √ ]":"[ × ]"}* Anti Bot
	◦  *${i.antiluar?"[ √ ]":"[ × ]"}* Anti Luar
	◦  *${i.antihidetag?"[ √ ]":"[ × ]"}* Anti Hidetag
	◦  *${i.antiviewonce?"[ √ ]":"[ × ]"}* Anti Viewonce
	◦  *${i.antidelete?"[ √ ]":"[ × ]"}* Anti Delete
	◦  *${i.antiedited?"[ √ ]":"[ × ]"}* Anti Edited
	◦  *${i.automatically?"[ √ ]":"[ × ]"}* Automatically
	◦  *${i.antigsmm?"[ √ ]":"[ × ]"}* Anti Group Status Mention Message

乂  *G R O U P - S T A T U S*

	◦  Muted : *${i.mute?"√":"×"}*
	◦  Kirim pesan : *${n.announce?"Hanya admin":"Semua peserta"}*
	◦  Edit info grup : *${n.restrict?"Hanya admin":"Semua peserta"}*
	◦  Expired : *${0==i.sewa.expired?"-":t.timeReverse(i.sewa.expired)}*`;a.sendMessageModify(e.chat,r,e,{largeThumb:!0,thumbnail:o,expiration:e.expiration})},group:!0,location:"plugins/group/groupinfo.js"};