//CREATE BY REZA DEVS KUROMI
exports.run={usage:["tagme"],category:"group",async:async(e,{kuromi:a,fkon:r})=>{a.reply(e.chat,"@"+e.sender.split("@")[0],r)},group:!0};