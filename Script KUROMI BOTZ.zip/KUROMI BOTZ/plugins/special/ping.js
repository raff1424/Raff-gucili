let performance=require("perf_hooks").performance,os=require("os");exports.run={usage:["ping"],category:"special",async:async(e,{func:o,kuromi:a})=>{var r=performance.now(),[t,i,m,n]=await Promise.all([(os.totalmem()/1024**3).toFixed(2)+" GB",(os.freemem()/1024**3).toFixed(2)+" GB",os.uptime(),os.cpus()[0]?.model??"Tidak diketahui"]),s=Math.floor(m/86400),p=Math.floor(m%86400/3600),c=Math.floor(m%3600/60),m=Math.floor(m%60),r=(performance.now()-r).toFixed(5)+" ms",n=`Server Information

- ${os.cpus().length} CPU: ${n}

- Uptime: ${s} hari, ${p} jam, ${c} menit, ${m} detik
- RAM: ${i}/${t}
- Speed: `+r;await a.reply(e.chat,o.texted("monospace",n),e,{expiration:e.expiration})}};