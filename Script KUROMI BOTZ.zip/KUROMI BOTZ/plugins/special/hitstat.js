//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch");exports.run={usage:["hitstat"],category:"special",async:async(i,{kuromi:t,setting:e})=>{if(0==Object.keys(global.db.statistic).length)return i.reply("No command used.");var a=Object.entries(global.db.statistic).sort((t,e)=>e[1].hit-t[1].hit),s=a.map(t=>t[0]),s=Math.min(10,s.length),r=`乂  *H I T - S T A T*

`,r=(r+=`*“Total command hit statistics are currently ${Object.entries(global.db.statistic).map(t=>t[1].hit).reduce((t,e)=>t+e)} Hits.”*
`)+a.slice(0,s).map(([t,e],a)=>`
${a+1}. *Command* :  ${i.prefix+t}
    *Hit* : ${e.hit}
    *Last Hit* : `+(Date.now()-e.lastused).timers()).join("\n");await(e.fakereply?t.sendMessageModify(i.chat,r,i,{title:global.header,body:global.footer,thumbnail:await(await fetch(e.cover)).buffer(),largeThumb:!0,expiration:i.expiration}):t.reply(i.chat,r,i,{expiration:i.expiration}))}};