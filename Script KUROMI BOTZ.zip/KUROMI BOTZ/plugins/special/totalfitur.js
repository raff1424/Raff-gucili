//CREATE BY REZA DEVS KUROMI
exports.run={usage:["totalfitur"],hidden:["fitur"],category:"special",async:async(e,{func:a,kuromi:r,plugins:s})=>{var t,u=Object.entries(s).filter(([,e])=>e.run&&e.run.usage),n=Object.fromEntries(u),o=[];for(t in n){var c=n[t].run;n&&c&&c.category&&(Object.keys(o).includes(c.category)||(o[c.category]=[]),o[c.category].push(c))}let g="乂  *F E A T U R E - L I S T*\n";for(let t of Object.keys(o).sort()){let e=Object.entries(s).filter(([,e])=>e.run.usage&&e.run.category==t.toLowerCase()),r=[];e.map(([,e])=>{switch(e.run.usage.constructor.name){case"Array":e.run.usage.map(e=>r.push({usage:e}));break;case"String":r.push({usage:e.run.usage})}}),g+=`
◦  ${a.ucword(t)} : ${r.sort((e,r)=>e.usage.localeCompare(r.usage)).length} feature`}g=(g+=`

*Total Plugins : ${Object.keys(s).length}*`)+`
*Total Feature : ${a.totalFeature(s)} Commands*`,r.reply(e.chat,g,e,{expiration:e.expiration})}};