//CREATE BY REZA DEVS KUROMI
let fs=require("fs"),path=require("path"),fetch=require("node-fetch");exports.run={usage:["dashboard"],hidden:["dash"],category:"special",async:async(t,{func:r,kuromi:e,setting:s})=>{let a="session",i=fs.readdirSync(a),o=0;i.map(e=>o+=fs.statSync(path.join(a,e)).size);var n=fs.statSync("./database/database.json").size,p=Object.entries(global.db.statistic).sort((e,s)=>s[1].hit-e[1].hit),n=`乂  *DASHBOARD MECHA BOT*

⭝ Runtime : ${r.clockString(1e3*process.uptime())}
⭝ System OS : ${process.platform+" "+process.arch}
⭝ Nodejs Version : ${process.version}
⭝ Total Session : ${i.length} Files
⭝ Size Session : ${o.sizeString()}
⭝ Size Database : ${n.sizeString()}
⭝ Ram Used Bot : ${process.memoryUsage.rss().sizeString(0)}
⭝ Max Ram Server : ${process.env.SERVER_MEMORY??0} MB
⭝ Time Server : ${process.env.TZ??"-"}
⭝ Location Server : ${process.env.P_SERVER_LOCATION??"-"}
⭝ Total Hit Bot : ${Object.entries(global.db.statistic).map(e=>e[1].hit).reduce((e,s)=>e+s)}
⭝ Total Database User : ${Object.keys(global.db.users).length} Users
⭝ Total Database Group : ${Object.keys(global.db.groups).length} Groups
⭝ Total Sampah : ${fs.readdirSync("./sampah").filter(s=>["gif","png","mp3","m4a","opus","mp4","jpg","jpeg","webp","webm"].some(e=>s.endsWith(e))).map(e=>e).length} Sampah
⭝ Top Fitur :
`+p.slice(0,10).map(([e,s],a)=>"\n"+(a+1)+". *Command* :  "+t.prefix+e+"\n    *Hit* : "+r.formatNumber(s.hit)+"\n    *Last Used* : "+(Date.now()-s.lastused).timers()).join("\n");await(s.fakereply?e.sendMessageModify(t.chat,n,t,{title:global.header,body:global.footer,thumbnail:await(await fetch(s.cover)).buffer(),largeThumb:!0,expiration:t.expiration}):e.reply(t.chat,n,t,{expiration:t.expiration}))}};