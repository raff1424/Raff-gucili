//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch");exports.run={usage:["listcmd"],category:"special",async:async(e,{kuromi:t,setting:a})=>{var r=Object.entries(global.db.stickercmd);if(0==r.length)return e.reply("*Empty data.*");var i=`乂  *LIST STICKER CMD*
`;i+=r.map(([,e],t)=>`
${t++}. ${e.text}
◦  Creator: @`+e.creator.split("@")[0]).join("\n"),await(a.fakereply?t.sendMessageModify(e.chat,i,e,{title:global.header,body:global.footer,thumbnail:await(await fetch(a.cover)).buffer(),largeThumb:!0,expiration:e.expiration}):t.reply(e.chat,i,e,{expiration:e.expiration}))}};