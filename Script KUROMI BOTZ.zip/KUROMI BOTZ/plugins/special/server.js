//CREATE BY REZA DEVS KUROMI
let os=require("os"),fetch=require("node-fetch");exports.run={usage:["server"],category:"special",async:async(e,{func:a,kuromi:o,setting:t})=>{var r,s=await a.fetchJson("http://ip-api.com/json");delete s.status;let i=`乂  *S E R V E R*

`;for(r in i=(i+=`┌  ◦  OS : ${os.type()} (${os.arch()} / ${os.release()})
`)+`│  ◦  Ram : ${a.formatSize(process.memoryUsage().rss)} / ${a.formatSize(os.totalmem())}
`,s)i+=`│  ◦  ${a.ucword(r)} : ${s[r]}
`;i=(i+=`│  ◦  Uptime : ${a.toTime(1e3*os.uptime)}
`)+`└  ◦  Processor : ${"linux"==process.platform?os.cpus()[0].model:"-"}

`,await(t.fakereply?o.sendMessageModify(e.chat,i,e,{title:global.header,body:global.footer,thumbnail:await(await fetch(t.cover)).buffer(),largeThumb:!0,expiration:e.expiration}):o.reply(e.chat,i,e,{expiration:e.expiration}))}};