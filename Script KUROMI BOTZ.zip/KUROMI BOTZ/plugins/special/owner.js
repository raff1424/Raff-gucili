//CREATE BY REZA DEVS KUROMI
exports.run={usage:["owner"],hidden:["creator","developer","dev"],category:"special",async:async(e,{kuromi:a})=>{a.sendkontak(e.chat,global.owner,global.ownerName,e)}};