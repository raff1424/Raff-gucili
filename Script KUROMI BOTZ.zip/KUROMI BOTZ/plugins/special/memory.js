//CREATE BY REZA DEVS KUROMI
exports.run={usage:["memory"],hidden:["ram"],category:"special",async:async(e,{func:o,kuromi:s})=>{var a=void 0!==process.env.SERVER_MEMORY&&0!=process.env.SERVER_MEMORY?process.env.SERVER_MEMORY+" MB":"∞",o=`${o.texted("monospace","Memory Information")}

${o.texted("monospace","- Ram Used Bot:")} ${o.texted("bold",o.fileSize(process.memoryUsage().rss))}
${o.texted("monospace","- Max Ram Server:")} `+o.texted("bold",a);s.reply(e.chat,o,e,{expiration:e.expiration})}};