//CREATE BY REZA DEVS KUROMI
let cooldown=9e5;function ranNumb(a,n=null){return null!==n?(a=Math.ceil(a),n=Math.floor(n),Math.floor(Math.random()*(n-a+1))+a):Math.floor(Math.random()*a)+1}exports.run={usage:["mulung"],category:"rpg",async:async(a,{func:n,kuromi:e,setting:l})=>{var u=global.db.users[a.sender],t=cooldown-(new Date-u.lastmulung);if(new Date-u.lastmulung<=cooldown)return a.reply(`Kamu sudah mulung dan kelelahan, mohon tunggu *${n.clockString(t)}*`);var n=ranNumb(10,100),t=ranNumb(10,100),o=ranNumb(10,100);u.botol+=n,u.kaleng+=t,u.kardus+=o;let r=`Selamat kamu mendapatkan :
+${n} Botol
+${o} Kardus
+${t} Kaleng`;a.reply("_Sedang memulung..._"),u.lastmulung=+new Date,setTimeout(()=>{e.reply(a.chat,r,a)},1e3*l.gamewaktu)},register:!0,limit:!0};