exports.run = {
  usage: ['berburumonster'],
  hidden: ['huntmonster'],
  use: 'Pergi berburu monster legendaris dan dapatkan hadiah besar (3 jam sekali)',
  category: 'rpg',
  async: async (m, { func, kuromi, users }) => {
    const cooldown = 3 * 60 * 60 * 1000
    const now = Date.now()

    if (users.lastHunt && now - users.lastHunt < cooldown) {
      const sisa = cooldown - (now - users.lastHunt)
      return m.reply(`Kamu baru saja berburu.\nCoba lagi dalam *${func.clockString(sisa)}*.`)
    }

    users.lastHunt = now

    const monster = [
      'Naga Api',
      'Fenrir Serigala Hitam',
      'Titan Batu',
      'Phoenix Abadi',
      'Leviathan Lautan'
    ]
    const target = monster[Math.floor(Math.random() * monster.length)]

    const langkah = [
      `Menyiapkan senjata dan bekal untuk berburu *${target}*...`,
      `Memasuki wilayah berbahaya tempat *${target}* bersemayam...`,
      `Melacak jejak dan tanda-tanda keberadaan *${target}*...`,
      `Bertemu dengan *${target}*, bersiap untuk pertempuran...`,
      `Mencoba mengalahkan atau menangkap *${target}*...`
    ]

    for (let i = 0; i < langkah.length; i++) {
      await m.reply(`Step ${i + 1}: ${langkah[i]}`)
      await func.delay(5000)
    }

    const hasil = Math.random()

    if (hasil < 0.25) {
      return m.reply(`───「 *BURUAN GAGAL* 」───\n\n*${target}* terlalu kuat!\nKamu terpaksa mundur tanpa hasil.`)
    } else if (hasil < 0.5) {
      const kerugian = Math.floor(Math.random() * (700 - 200 + 1)) + 200
      users.balance = Math.max(0, users.balance - kerugian)
      return m.reply(`───「 *CEDERA!* 」───\n\nSaat bertarung melawan *${target}*, kamu terluka.\nKamu kehilangan *${func.formatRupiah ? func.formatRupiah(kerugian) : kerugian}* untuk biaya pengobatan.`)
    } else {
      const rewardMoney = Math.floor(Math.random() * (9000 - 3000 + 1)) + 3000
      const rareItem = ['Pedang Legenda', 'Armor Phoenix', 'Cincin Titan', 'Jubah Penyihir', 'Kalung Leviathan']
      const item = rareItem[Math.floor(Math.random() * rareItem.length)]

      users.balance += rewardMoney

      // Simpan ke inventory kalau mau support inventory nanti.
      // users.inventory.push(item)

      return m.reply(
        `───「 *BERBURU BERHASIL* 」───\n\n` +
        `Kamu berhasil menaklukkan *${target}*!\n\n` +
        `Hadiah:\n+ ${func.formatRupiah ? func.formatRupiah(rewardMoney) : rewardMoney}\n+ Item Langka: *${item}*`
      )
    }
  },
  group: true,
  location: 'plugins/rpg/berburumonster'
}