//CREATE BY REZA DEVS KUROMI
function ranNumb(a,i=null){return null!==i?(a=Math.ceil(a),i=Math.floor(i),Math.floor(Math.random()*(i-a+1))+a):Math.floor(Math.random()*a)+1}exports.run={usage:["berkebon"],hidden:["berkebun"],category:"rpg",async:async(a,{func:i,kuromi:b,setting:e})=>{var t,r=100;let n=global.db.users[a.sender];if(new Date-n.lastberkebon<=45e5)return a.reply(`Kamu sudah berkebun, mohon tunggu *${i.clockString(n.lastberkebon+45e5-new Date)}*`);if(0==n.pickaxe)return a.reply(`Perlu *${a.prefix}craft* pickaxe terlebih dahulu.

Anda memiliki :
⛏️ ${n.pickaxe} PickAxe`);let u=[{buah:0},{buah:0},{buah:0},{buah:0},{buah:0}];for(t of u){var g=ranNumb(80,100);t.buah+=g}if(!(99<n.bibitmangga&&99<n.bibitapel&&99<n.bibitpisang&&99<n.bibitjeruk&&99<n.bibitanggur))return a.reply(`Diperlukan masing-masing *100* bibit terdiri dari bibitmangga, bibitapel, bibitpisang, bibitjeruk, bibitanggur

Kamu memiliki :
- 🌾 ${n.bibitmangga} bibitmangga
- 🌾 ${n.bibitapel} bibitapel
- 🌾 ${n.bibitpisang} bibitpisang
- 🌾 ${n.bibitjeruk} bibitjeruk
- 🌾 ${n.bibitanggur} bibitanggur`);n.bibitmangga-=r,n.bibitapel-=r,n.bibitpisang-=r,n.bibitjeruk-=r,n.bibitanggur-=r,n.pickaxedurability-=ranNumb(80,120),n.pickaxedurability<=0&&(n.pickaxedurability=0,n.pickaxe=0),a.reply("_Sedang Berkebun..._"),n.lastberkebon=+new Date,setTimeout(()=>{n.mangga+=u[0].buah,n.apel+=u[1].buah,n.pisang+=u[2].buah,n.jeruk+=u[3].buah,n.anggur+=u[4].buah,b.sendMessageModify(a.chat,`乂  *R P G - B E R K E B U N*

Kamu mendapatkan :
🥭 +${u[0].buah} Mangga
🍎 +${u[1].buah} Apel
🍌 +${u[2].buah} Pisang
🍊 +${u[3].buah} Jeruk
🍇 +${u[4].buah} Anggur`,a,{title:global.header,body:global.footer,thumbUrl:"https://i.ibb.co/XpyTNc6/pickebon.jpg",largeThumb:!0,expiration:a.expiration})},1e3*e.gamewaktu)},register:!0,limit:!0};