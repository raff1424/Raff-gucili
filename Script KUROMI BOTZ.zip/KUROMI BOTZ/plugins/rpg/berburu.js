//CREATE BY REZA DEVS KUROMI
function ranNumb(a,e=null){return null!==e?(a=Math.ceil(a),e=Math.floor(e),Math.floor(Math.random()*(e-a+1))+a):Math.floor(Math.random()*a)+1}exports.run={usage:["berburu"],hidden:["hunting","hunt"],category:"rpg",async:async(a,{func:e,kuromi:n,setting:r})=>{var h;let t=global.db.users[a.sender];if(new Date-t.lasthunt<=36e5)return a.reply(`Kamu sudah berburu, mohon tunggu *${e.clockString(t.lasthunt+36e5-new Date)}*`);if(0==t.armor||0==t.sword||0==t.bow)return a.reply(`Perlu *${a.prefix}craft* armor, sword, dan bow terlebih dahulu.

Anda memiliki :
- 🥼 ${t.armor} Armor
- ⚔️ ${t.sword} Sword
- 🏹 ${t.bow} Bow`);let i=[{hewan:0},{hewan:0},{hewan:0},{hewan:0},{hewan:0},{hewan:0},{hewan:0},{hewan:0},{hewan:0},{hewan:0},{hewan:0},{hewan:0}];for(h of i){var w=ranNumb(1,5);h.hewan+=w}let u=`乂  *R P G - B E R B U R U*

Hasil tangkapan hari ini :
*🐂 Banteng :* ${i[0].hewan}
*🐅 Harimau :* ${i[1].hewan}
*🐘 Gajah :* ${i[2].hewan}
*🐐 Kambing :* ${i[3].hewan}
*🐼 Panda :* ${i[4].hewan}
*🐊 Buaya :* ${i[5].hewan}
*🐃 Kerbau :* ${i[6].hewan}
*🐮 Sapi :* ${i[7].hewan}
*🐒 Monyet :* ${i[8].hewan}
*🐗 Babi hutan :* ${i[9].hewan}
*🐖 Babi :* ${i[10].hewan}
*🐓 Ayam :* `+i[11].hewan;t.armordurability-=ranNumb(80,120),t.sworddurability-=ranNumb(80,120),t.bowdurability-=ranNumb(80,120),t.armordurability<=0&&(t.armordurability=0,t.armor=0),t.sworddurability<=0&&(t.sworddurability=0,t.sword=0),t.bowdurability<=0&&(t.bowdurability=0,t.bow=0),t.lasthunt=+new Date,a.reply("_Perburuan Dimulai..._"),setTimeout(()=>{t.banteng+=i[0].hewan,t.harimau+=i[1].hewan,t.gajah+=i[2].hewan,t.kambing+=i[3].hewan,t.panda+=i[4].hewan,t.buaya+=i[5].hewan,t.kerbau+=i[6].hewan,t.sapi+=i[7].hewan,t.monyet+=i[8].hewan,t.babihutan+=i[9].hewan,t.babi+=i[10].hewan,t.ayam+=i[11].hewan,n.sendMessageModify(a.chat,u,a,{title:global.header,body:global.footer,thumbUrl:"https://telegra.ph/file/295a6d5105771875e1797.jpg",largeThumb:!0,expiration:a.expiration})},1e3*r.gamewaktu)},register:!0,limit:!0};