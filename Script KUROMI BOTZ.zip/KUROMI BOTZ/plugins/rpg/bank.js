//CREATE BY REZA DEVS KUROMI
exports.run={usage:["bank"],hidden:["atm"],use:"options",category:"rpg",async:async(e,{func:a,kuromi:r})=>{var n=e.quoted?e.quoted.sender:e.mentionedJid[0]||e.sender,t=global.db.users[e.sender],i=global.db.users[n];if(!e.args[0]||"create"!==e.args[0].toLowerCase())return i?i.register?t.level<i.level?e.reply("Tidak dapat melihat karena level target lebih tinggi."):(r=`Aset *${(await r.getName(n)).replaceAll("\n","")}*

*Bank :* ${i.atm}
*Money :* ${a.rupiah(i.money)}
*Gold :* ${i.gold}
*Diamond :* ${i.diamond}
*Emerald :* `+i.emerald,void e.reply(r)):e.reply("Pengguna tersebut belum terverifikasi."):e.reply("User tidak ada didalam database.");0<t.atm?e.reply("Kamu sudah membuat rekening."):t.money<5e4?e.reply("Minimal memiliki 50.000 money untuk deposit."):(t.money-=5e4,t.atm+=5e4,e.reply("Berhasil membuat rekening."))},register:!0};