exports.run = {
  usage: ['ekspedisi'],
  hidden: ['expedition'],
  use: 'Ikuti ekspedisi berbahaya dan rebut hadiah besar! (3 jam sekali)',
  category: 'rpg',
  async: async (m, { func, kuromi, users }) => {
    const cooldown = 3 * 60 * 60 * 1000
    const now = Date.now()

    if (users.lastExpedition && now - users.lastExpedition < cooldown) {
      const sisa = cooldown - (now - users.lastExpedition)
      return m.reply(`Kamu masih kelelahan dari ekspedisi sebelumnya.\nCoba lagi dalam *${func.clockString(sisa)}*.`)
    }

    const lokasi = [
      'Lembah Kematian',
      'Pulau Hantu',
      'Hutan Gelap',
      'Gua Es Abadi',
      'Kuil Terlarang'
    ]

    const tempat = lokasi[Math.floor(Math.random() * lokasi.length)]
    const langkah = [
      `Memulai perjalanan menuju *${tempat}*...`,
      'Menghadapi badai dan binatang buas...',
      'Mencari jalur rahasia untuk masuk...',
      'Mendekati pusat lokasi ekspedisi...',
      'Menghadapi ujian terakhir di depanmu...'
    ]

    users.lastExpedition = now

    for (let i = 0; i < langkah.length; i++) {
      await m.reply(`Step ${i + 1}: ${langkah[i]}`)
      await func.delay(5000)
    }

    const outcome = Math.random()
    if (outcome < 0.2) {
      return m.reply(`───「 *EKSPEDISI GAGAL* 」───\n\nSaat mencoba bertahan di *${tempat}*, kamu terjebak!\nKamu kehilangan semangat dan tidak membawa apapun pulang.`)
    } else if (outcome < 0.4) {
      const kerugian = Math.floor(Math.random() * (500 - 100 + 1)) + 100
      users.balance = Math.max(0, users.balance - kerugian)
      return m.reply(`───「 *TERJEBAK!* 」───\n\nKamu jatuh ke dalam perangkap di *${tempat}*.\nKamu kehilangan *${func.formatRupiah ? func.formatRupiah(kerugian) : kerugian}* sebagai tebusan!`)
    } else {
      const reward = Math.floor(Math.random() * (7000 - 1000 + 1)) + 1000
      users.balance += reward
      return m.reply(`───「 *EKSPEDISI SUKSES* 」───\n\nKamu berhasil menemukan harta karun tersembunyi di *${tempat}*!\nHadiah: +${func.formatRupiah ? func.formatRupiah(reward) : reward}`)
    }
  },
  group: true,
  location: 'plugins/rpg/ekspedisi'
}