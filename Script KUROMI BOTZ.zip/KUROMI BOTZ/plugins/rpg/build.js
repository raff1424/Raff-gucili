//CREATE BY REZA DEVS KUROMI
function isNumber(a){return a&&"number"==typeof(a=parseInt(a))&&!isNaN(a)}exports.run={usage:["build"],hidden:["building"],use:"[item] [count]",category:"rpg",async:async(a,{})=>{var e=global.db.users[a.sender],n=`乂  *B U I L D I N G - L I S T*

%🏥 rumahsakit%
%🏭 restoran%
%🏯 pabrik%
%⚒️ tambang%
%🛳️ pelabuhan%

Format: *${a.cmd} [item] [jumlah]*
Contoh: *${a.cmd} restoran 2*`,l=(a.args[0]||"").toLowerCase(),m=+Math.floor(isNumber(a.args[1])?Math.min(Math.max(parseInt(a.args[1]),1),Number.MAX_SAFE_INTEGER):1);return"rumahsakit"==l?0==e.rumahsakit?1<m?a.reply("Kamu belum memiliki *🏥 Rumah Sakit*, hanya dapat build 1 bangunan"):e.money<9e5*m||e.sand<600*m?a.reply(`Diperlukan ${9e5*m} money, ${600*m} sand.

Anda memiliki :
- ${e.money} money
- ${e.sand} sand`):(e.money-=9e5*m,e.sand-=600*m,e.rumahsakit+=m,e.rumahsakitlvl+=1,void a.reply(`Berhasil membangun *${m} 🏥 Rumah Sakit* level ${e.rumahsakitlvl}.

command *${a.prefix}stat* untuk mengecek bonus stat pet / building`)):e.rumahsakit+m>2*e.rumahsakitlvl?a.reply(`Perlu upgrade 🏥 rumahsakit ke level ${2*e.rumahsakitlvl} terlebih dahulu.`):e.money<9e5*m*e.rumahsakitlvl||e.sand<600*m*e.rumahsakitlvl?a.reply(`Diperlukan ${9e5*m*e.rumahsakitlvl} money, ${600*m*e.rumahsakitlvl} sand.

Anda memiliki :
- ${e.money} money
- ${e.sand} sand`):(e.money-=9e5*m*e.rumahsakitlvl,e.sand-=600*m*e.rumahsakitlvl,e.rumahsakit+=m,void a.reply(`Berhasil membangun *${m} 🏥 Rumah Sakit* level ${e.rumahsakitlvl}.

command *${a.prefix}stat* untuk mengecek bonus stat pet / building`)):"restoran"==l?0==e.restoran?1<m?a.reply("Kamu belum memiliki *🏭 Restoran*, hanya dapat build 1 bangunan"):e.money<1e6*m||e.sand<333*m||e.steel<50*m||e.masakcount<50*m?a.reply(`Diperlukan ${1e6*m} money, ${333*m} sand, ${50*m} steel, dan pengalaman masak ${50*m} kali.

Anda memiliki :
- ${e.money} money
- ${e.sand} sand
- ${e.steel} steel
- pengalaman masak : ${e.masakcount} kali`):(e.money-=1e6*m,e.sand-=333*m,e.steel-=50*m,e.restoran+=m,e.restoranlvl+=1,void a.reply(`Berhasil membangun *${m} 🏭 Restoran* level ${e.restoranlvl}.

command *${a.prefix}stat* untuk mengecek bonus stat pet / building`)):e.restoran+m>2*e.restoranlvl?a.reply(`Perlu upgrade 🏭 restoran ke level ${2*e.restoranlvl} terlebih dahulu.`):e.money<125e4*m||e.sand<333*m||e.steel<50*m||e.masakcount<50*m?a.reply(`Diperlukan ${125e4*m} money, ${333*m} sand, ${50*m} steel, dan pengalaman masak ${50*m} kali.

Anda memiliki :
- ${e.money} money
- ${e.sand} sand
- ${e.steel} steel
- pengalaman masak : ${e.masakcount} kali`):(e.money-=125e4*m,e.sand-=333*m,e.steel-=50*m,e.restoran+=m,void a.reply(`Berhasil membangun *${m} 🏭 Restoran* level ${e.restoranlvl}.

command *${a.prefix}stat* untuk mengecek bonus stat pet / building`)):"pabrik"==l?0==e.pabrik?1<m?a.reply("Kamu belum memiliki *🏯 Pabrik*, hanya dapat build 1 bangunan"):e.money<5e5*m||e.sand<166*m||e.steel<25*m||e.craftcount<50*m?a.reply(`Diperlukan ${5e5*m} money, ${166*m} sand, ${25*m} steel, dan pengalaman crafting ${50*m} kali.

Anda memiliki :
- ${e.money} money
- ${e.sand} sand
- ${e.steel} steel
- pengalaman crafting : ${e.craftcount} kali`):(e.money-=5e5*m,e.sand-=166*m,e.steel-=25*m,e.pabrik+=m,e.pabriklvl+=1,void a.reply(`Berhasil membangun *${m} 🏯 Pabrik* level ${e.pabriklvl}.

command *${a.prefix}stat* untuk mengecek bonus stat pet / building`)):e.pabrik+m>2*e.pabriklvl?a.reply(`Perlu upgrade 🏯 pabrik ke level ${2*e.pabriklvl} terlebih dahulu.`):e.money<5e5*m||e.sand<166*m||e.steel<25*m||e.craftcount<50*m?a.reply(`Diperlukan ${5e5*m} money, ${166*m} sand, ${25*m} steel, dan pengalaman crafting ${50*m} kali.

Anda memiliki :
- ${e.money} money
- ${e.sand} sand
- ${e.steel} steel
- pengalaman crafting : ${e.craftcount} kali`):(e.money-=5e5*m,e.sand-=166*m,e.steel-=25*m,e.pabrik+=m,void a.reply(`Berhasil membangun *${m} 🏯 Pabrik* level ${e.pabriklvl}.

command *${a.prefix}stat* untuk mengecek bonus stat pet / building`)):"tambang"==l?0==e.tambang?1<m?a.reply("Kamu belum memiliki *⚒️ Tambang*, hanya dapat build 1 bangunan"):e.money<1e6*m||e.iron<166*m||e.steel<30*m||e.adventurecount<50*m?a.reply(`Diperlukan ${1e6*m} money, ${166*m} iron, ${30*m} steel, dan pengalaman adventure ${50*m} kali.

Anda memiliki :
- ${e.money} money
- ${e.iron} iron
- ${e.steel} steel
- pengalaman adventure : ${e.adventurecount} kali`):(e.money-=1e6*m,e.iron-=166*m,e.steel-=30*m,e.tambang+=m,e.tambanglvl+=1,void a.reply(`Berhasil membangun *${m} ⚒️ tambang* level ${e.tambanglvl}.

command *${a.prefix}stat* untuk mengecek bonus stat pet / building`)):e.tambang+m>2*e.tambanglvl?a.reply(`Perlu upgrade ⚒️ tambang ke level ${2*e.tambanglvl} terlebih dahulu.`):e.money<1e6*m||e.iron<166*m||e.steel<30*m||e.adventurecount<50*m?a.reply(`Diperlukan ${1e6*m} money, ${166*m} iron, ${30*m} steel, dan pengalaman adventure ${50*m} kali.

Anda memiliki :
- ${e.money} money
- ${e.iron} iron
- ${e.steel} steel
- pengalaman adventure : ${e.adventurecount} kali`):(e.money-=1e6*m,e.iron-=166*m,e.steel-=30*m,e.tambang+=m,void a.reply(`Berhasil membangun *${m} ⚒️ Tambang* level ${e.tambanglvl}.

command *${a.prefix}stat* untuk mengecek bonus stat pet / building`)):"pelabuhan"==l?0==e.pelabuhan?1<m?a.reply("Kamu belum memiliki *🛳️ Pelabuhan*, hanya dapat build 1 bangunan"):e.money<5e5*m||e.kargo<6*m||e.kapal<6*m||e.mancingcount<50*m?a.reply(`Diperlukan ${5e5*m} money, ${6*m} kargo, ${6*m} kapal, dan pengalaman mancing ${50*m} kali.

Anda memiliki :
- ${e.money} money
- ${e.kargo} kargo
- ${e.kapal} kapal
- pengalaman mancing : ${e.mancingcount} kali`):(e.money-=5e5*m,e.kargo-=6*m,e.kapal-=6*m,e.pelabuhan+=m,e.pelabuhanlvl+=1,void a.reply(`Berhasil membangun *${m} 🛳️ Pelabuhan* level ${e.pelabuhanlvl}.

command *${a.prefix}stat* untuk mengecek bonus stat pet / building`)):e.pelabuhan+m>2*e.pelabuhanlvl?a.reply(`Perlu upgrade 🛳️ pelabuhan ke level ${2*e.pelabuhanlvl} terlebih dahulu.`):e.money<5e5*m||e.kargo<6*m||e.kapal<6*m||e.mancingcount<50*m?a.reply(`Diperlukan ${5e5*m} money, ${6*m} kargo, ${6*m} kapal, dan pengalaman mancing ${50*m} kali.

Anda memiliki :
- ${e.money} money
- ${e.kargo} kargo
- ${e.kapal} kapal
- pengalaman mancing : ${e.mancingcount} kali`):(e.money-=5e5*m,e.kargo-=6*m,e.kapal-=6*m,e.pelabuhan+=m,void a.reply(`Berhasil membangun *${m} 🛳️ pelabuhan* level ${e.pelabuhanlvl}.

command *${a.prefix}stat* untuk mengecek bonus stat pet / building`)):void a.reply(n.replaceAll("%","```"))},register:!0,limit:!0};