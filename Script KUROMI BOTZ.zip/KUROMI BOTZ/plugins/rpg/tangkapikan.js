exports.run = {
  usage: ['tangkapikan'],
  hidden: ['fishcatch'],
  use: 'Tangkap ikan yang muncul dan dapatkan hadiah!',
  category: 'rpg',
  async: async (m, { func, kuromi, users }) => {
    const cooldown = 2 * 60 * 60 * 1000
    const now = Date.now()

    if (users.lastCatch && now - users.lastCatch < cooldown) {
      const sisa = cooldown - (now - users.lastCatch)
      return m.reply(`Kamu baru saja menangkap ikan. Cobalah lagi dalam *${func.clockString(sisa)}*.`)
    }

    const ikan = ['ikan kecil', 'ikan sedang', 'ikan besar', 'ikan raksasa']
    const ikanTerpilih = ikan[Math.floor(Math.random() * ikan.length)]

    const taruhan = parseInt(m.args[0])

    if (isNaN(taruhan) || taruhan <= 0) {
      return m.reply('Masukkan jumlah taruhan yang valid!')
    }

    if (users.balance < taruhan) {
      return m.reply('Kamu tidak memiliki saldo yang cukup untuk bertaruh.')
    }

    users.lastCatch = now

    let reward = 0
    let hasil = ''
    
    switch (ikanTerpilih) {
      case 'ikan kecil':
        reward = taruhan * 1
        hasil = 'Kamu menang dengan ikan kecil. Hadiah: +1x taruhan!'
        break
      case 'ikan sedang':
        reward = taruhan * 2
        hasil = 'Kamu menang dengan ikan sedang. Hadiah: +2x taruhan!'
        break
      case 'ikan besar':
        reward = taruhan * 5
        hasil = 'Kamu menang dengan ikan besar. Hadiah: +5x taruhan!'
        break
      case 'ikan raksasa':
        reward = taruhan * 10
        hasil = 'Wow! Kamu menang dengan ikan raksasa! Hadiah: +10x taruhan!'
        break
    }

    if (reward > 0) {
      users.balance += reward
      return m.reply(
        `───「 *MENANGKAP IKAN* 」───\n\n` +
        `Ikan yang berhasil kamu tangkap: *${ikanTerpilih}*\n` +
        `${hasil}\n` +
        `Hadiah: +${func.formatRupiah ? func.formatRupiah(reward) : reward}`
      )
    } else {
      users.balance -= taruhan
      return m.reply(
        `───「 *MENANGKAP IKAN* 」───\n\n` +
        `Sayang sekali, kamu tidak mendapatkan ikan yang cukup besar.\n` +
        `Kamu kehilangan taruhan sebesar ${func.formatRupiah ? func.formatRupiah(taruhan) : taruhan}.`
      )
    }
  }
}