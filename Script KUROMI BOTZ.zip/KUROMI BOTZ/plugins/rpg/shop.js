//CREATE BY REZA DEVS KUROMI
let items={buy:{potion:{money:1250},wood:{money:2e3},aqua:{money:1e3},rock:{money:2e3},string:{money:2500},iron:{money:3e3},sand:{money:1500},emerald:{money:2e5},diamond:{money:3e5},gold:{money:1e5},petfood:{money:2500},bawang:{money:150},cabai:{money:250},kemiri:{money:100},jahe:{money:100},saus:{money:70},asam:{money:50},bibitapel:{money:150},bibitanggur:{money:200},bibitmangga:{money:250},bibitpisang:{money:50},bibitjeruk:{money:300},common:{money:1e4},uncommon:{money:15e3},mythic:{money:25e3},legendary:{money:4e4},banteng:{money:11e3},harimau:{money:18e3},gajah:{money:16e3},kambing:{money:12e3},panda:{money:2e4},buaya:{money:5e3},kerbau:{money:9e3},sapi:{money:1e4},monyet:{money:5e3},babihutan:{money:4e3},babi:{money:8e3},ayam:{money:3e3},orca:{money:2e4},paus:{money:45e3},lumba:{money:5e3},hiu:{money:4500},ikan:{money:2500},lele:{money:3e3},bawal:{money:3500},nila:{money:3e3},kepiting:{money:7e3},lobster:{money:15e3},gurita:{money:3e3},cumi:{money:5e3},udang:{money:7500},horse:{money:5e5},cat:{money:5e5},fox:{money:5e5},dog:{money:5e5},wolf:{money:1e6},centaur:{gold:15},phoenix:{emerald:10},dragon:{diamond:10},rumahsakit:{money:2e6},restoran:{money:25e5},pabrik:{money:1e6},tambang:{money:2e6},pelabuhan:{money:25e5}},sell:{potion:{money:125},petfood:{money:125},trash:{money:20},botol:{money:50},kaleng:{money:150},kardus:{money:100},banteng:{money:9900},harimau:{money:16200},gajah:{money:14400},kambing:{money:10800},panda:{money:18e3},buaya:{money:4500},kerbau:{money:8100},sapi:{money:9e3},monyet:{money:4500},babihutan:{money:3600},babi:{money:7200},ayam:{money:2700},orca:{money:18e3},paus:{money:40500},lumba:{money:4500},hiu:{money:4050},ikan:{money:2250},lele:{money:2700},bawal:{money:3150},nila:{money:2700},kepiting:{money:6300},lobster:{money:13500},gurita:{money:2700},cumi:{money:4500},udang:{money:6750},mangga:{money:400},anggur:{money:300},jeruk:{money:450},pisang:{money:200},apel:{money:300},steak:{money:35e3},sate:{money:45e3},rendang:{money:31e3},kornet:{money:27e3},nugget:{money:32e3},bluefin:{money:65e3},seafood:{money:65e3},sushi:{money:54500},moluska:{money:65e3},squidprawm:{money:60500},horse:{money:45e4},cat:{money:45e4},fox:{money:45e4},dog:{money:45e4},wolf:{money:9e5},centaur:{money:135e4},phoenix:{money:18e5},dragon:{money:27e5},rumahsakit:{money:18e5},restoran:{money:225e4},pabrik:{money:9e5},tambang:{money:18e5},pelabuhan:{money:225e4}}},processItems=(n,e,a)=>{var o,m=e.reduce((e,a)=>e+parseInt(n[a]||0),0);if(0===m)return`Kamu tidak memiliki *${a}* untuk dijual.`;let i=0;for(o of e){var y=parseInt(n[o]||0);n[o]-=y,i+=items.sell[o].money*y}return`Menjual *${m} ${a}* dengan harga *${i} money*`};exports.run={usage:["buy","sell"],use:"[item] [count]",category:"rpg",async:async(e,{func:a})=>{var n=`Format : *${e.cmd} [item] [jumlah]*
Contoh : *${e.cmd} potion 10*

*D A I L Y - I T E M S*
%| potion%
%| aqua%
%| petfood%

*C R A F T - I T E M S*
%| wood | rock%
%| string | iron%
%| sand | emerald%
%| diamond | gold%

*COOKING - INGREDIENTS*${a.readmore}
%| bawang | cabai%
%| kemiri | jahe%
%| saus | asam%

*GARDENING - MATERIALS*
%| bibitmangga%
%| bibitapel%
%| bibitpisang%
%| bibitjeruk%
%| bibitanggur%

*G A C H A - B O X*
%| common%
%| uncommon%
%| mythic%
%| legendary%

*L A N D - A N I M A L S*
%| banteng | harimau%
%| gajah | kambing%
%| panda | buaya%
%| kerbau | sapi%
%| monyet | babihutan%
%| babi | ayam%

*S E A - A N I M A L S*
%| orca | paus%
%| lumba | hiu%
%| ikan | lele%
%| bawal | nila%
%| kepiting | lobster%
%| gurita | cumi%
%| udang%

*P E T - S H O P*
%| horse | cat%
%| fox | dog%
%| wolf | centaur%
%| phoenix | dragon%

*B U I L D I N G S*
%| rumahsakit%
%| estoran%
%| pabrik%
%| tambang%
%| pelabuhan%`,o=`Format : *${e.cmd} [item] [jumlah]*
Contoh : *${e.cmd} potion 10*

*D A I L Y - I T E M S*
%| potion%
%| petfood%
%| trash%

*S E L L - A N I M A L S*
%| banteng | harimau%
%| gajah | kambing%
%| panda | buaya%
%| kerbau | sapi%
%| monyet | babihutan%
%| babi | ayam%

*S E A - A N I M A L S*${a.readmore}
%| orca | paus%
%| lumba | hiu%
%| ikan | lele%
%| bawal | nila%
%| kepiting | lobster%
%| gurita | cumi%
%| udang%

*S E L L - F R U I T S*
%| mangga%
%| anggur%
%| jeruk%
%| pisang%
%| apel%

*P E T - S E L L*
%| horse | cat%
%| fox | dog%
%| wolf | centaur%
%| phoenix | dragon%

*B U I L D I N G S*
%| rumahsakit%
%| estoran%
%| pabrik%
%| tambang%
%| pelabuhan%`;let m=global.db.users[e.sender];var i=/^(buy|shop|beli)$/i.test(e.command),y=i?"buy":"sell",y=Object.fromEntries(Object.entries(items[y]).filter(([e])=>e&&e in m)),r=(e.args[0]||"").toLowerCase(),a=Math.floor(a.isNumber(e.args[1])?Math.min(Math.max(parseInt(e.args[1]),1),Number.MAX_SAFE_INTEGER):1);if(!y[r]&&i)return e.reply(n.replace(/%/g,"```"));if(/^(sell|jual)$/i.test(e.command)){if(!y[r])return e.reply(o.replace(/%/g,"```"));if((n={"hewan darat":["banteng","harimau","gajah","kambing","panda","buaya","kerbau","sapi","monyet","babihutan","babi","ayam"],"hewan laut":["orca","paus","lumba","hiu","ikan","lele","bawal","nila","kepiting","lobster","gurita","cumi","udang"],buah:["mangga","anggur","jeruk","pisang","apel"]})[i=e.text.toLowerCase()])return e.reply(processItems(m,n[i],i))}return o=Object.keys(y[r]).find(e=>e in m),m[o]<y[r][o]*a?e.reply(`Kamu tidak memiliki cukup ${o} untuk membeli *${a} ${r}*.`):(m[o]-=y[r][o]*a,m[r]=(m[r]||0)+a,e.reply(`Membeli *${a} ${r}* seharga *${y[r][o]*a} ${o}*`))},register:!0};