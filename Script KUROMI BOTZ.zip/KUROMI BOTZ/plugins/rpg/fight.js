exports.run = {
  usage: ['pertarungan'],
  hidden: ['fight'],
  use: 'Bertarung melawan monster untuk mendapatkan hadiah!',
  category: 'rpg',
  async: async (m, { func, kuromi, users }) => {
    const cooldown = 2 * 60 * 60 * 1000
    const now = Date.now()

    if (users.lastFight && now - users.lastFight < cooldown) {
      const sisa = cooldown - (now - users.lastFight)
      return m.reply(`Kamu baru saja bertarung. Cobalah lagi dalam *${func.clockString(sisa)}*.`)
    }

    users.lastFight = now

    const monsters = [
      'Goblin', 'Troll', 'Orc', 'Dragon', 'Vampire', 'Zombie', 'Golem', 'Phoenix', 
      'Griffin', 'Minotaur', 'Hydra', 'Behemoth', 'Werewolf', 'Manticore', 'Basilisk', 
      'Giant', 'Sphinx', 'Chimera', 'Kraken', 'Cerberus'
    ]
    const monsterTerpilih = monsters[Math.floor(Math.random() * monsters.length)]
    const hpMonster = Math.floor(Math.random() * 200) + 100
    const damageMonster = Math.floor(Math.random() * 30) + 10

    // Menentukan apakah taruhan diperlukan
    const taruhan = Math.random() > 0.5 ? Math.floor(Math.random() * 500) + 100 : 0

    const hpUser = 100 // HP pengguna tetap 100 untuk sementara
    let hpAkhirUser = hpUser
    let hpAkhirMonster = hpMonster

    while (hpAkhirUser > 0 && hpAkhirMonster > 0) {
      hpAkhirMonster -= Math.floor(Math.random() * 20) + 10 // Serangan acak dari user
      hpAkhirUser -= damageMonster // Serangan monster

      if (hpAkhirMonster <= 0) {
        break
      }
    }

    let hadiah = 0
    let hasil = ''

    if (hpAkhirMonster <= 0) {
      hadiah = taruhan > 0 ? taruhan * 3 : Math.floor(Math.random() * 3000) + 500
      hasil = `Selamat! Kamu berhasil mengalahkan *${monsterTerpilih}*!\nKamu mendapatkan +${func.formatRupiah ? func.formatRupiah(hadiah) : hadiah}!`
    } else {
      hasil = `Sayang sekali, kamu kalah melawan *${monsterTerpilih}*.\nCobalah lagi!`
    }

    if (hadiah > 0) {
      users.balance += hadiah
    }

    return m.reply(
      `───「 *PERTARUNGAN* 」───\n\n` +
      `Monster yang kamu hadapi: *${monsterTerpilih}*\n` +
      `HP Monster: ${hpMonster}\n` +
      `HP Kamu: ${hpUser}\n\n` +
      `${hasil}`
    )
  }
}