//CREATE BY REZA DEVS KUROMI
let cooldown=9e5;function ranNumb(n,a=null){return null!==a?(n=Math.ceil(n),a=Math.floor(a),Math.floor(Math.random()*(a-n+1))+n):Math.floor(Math.random()*n)+1}exports.run={usage:["mining"],hidden:["menambang"],category:"rpg",async:async(n,{func:a,kuromi:e,setting:r})=>{var t=global.db.users[n.sender],o=cooldown-(new Date-t.lastmining);if(t.health<80)return n.reply(`Butuh minimal *❤️ 80 Health* untuk ${n.command}!

Ketik *${n.prefix}heal* untuk menambah health.
Atau *${n.prefix}use potion* untuk menggunakan potion.`);if(new Date-t.lastmining<=cooldown)return n.reply(`Kamu sudah berpetualang, mohon tunggu *${a.clockString(o)}*`);var a=ranNumb(1e3,3e3),o=ranNumb(10,100),m=ranNumb(10,50),u=ranNumb(10,30),l=ranNumb(10,20),i=ranNumb(50,100),h=ranNumb(10,100),g=ranNumb(3,10);t.money+=a,t.iron+=o,t.gold+=m,t.emerald+=l,t.diamond+=u,t.rock+=i,t.trash+=h,t.health-=g;let d=`乂  *R P G - M I N I N G*

❤️health *-${g}*
Anda membawa pulang :
*Money :* ${a}
*Iron :* ${o}
*Gold :* ${m}
*Emerald :* ${l}
*Diamond :* ${u}
*Rock :* ${i}
*Trash :* `+h;n.reply("_Sedang menambang..._"),t.lastmining=+new Date,setTimeout(()=>{e.reply(n.chat,d,n)},1e3*r.gamewaktu)},register:!0,limit:!0};