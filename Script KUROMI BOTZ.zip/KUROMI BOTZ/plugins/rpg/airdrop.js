exports.run = {
  usage: ['airdrop'],
  hidden: [],
  use: 'Mendapatkan hadiah dari airdrop',
  category: 'rpg',
  async: async (m, { func, kuromi, isPrem, users }) => {
    let timeout = 3600000; // 1 jam dalam milidetik

 
    let u = users
    let time = u.lastclaim + timeout;

    if (new Date() - u.lastclaim < timeout) {
      return kuromi.sendMessage(m.chat, { 
        text: `*Sudah Melakukan Pencarian Airdrop!* 🪙\nHarus menunggu selama ${clockString(time - new Date())} agar bisa mencari Airdrop kembali.` 
      }, { quoted: m });
    }

    let Aku = Math.floor(Math.random() * 101);
    let Kamu = Math.floor(Math.random() * 81);

    if (Aku > Kamu) {
      let sampah = Math.floor(Math.random() * 50) + 1;
      let kayu = Math.floor(Math.random() * 50) + 1;
      let batu = Math.floor(Math.random() * 50) + 1;

      kuromi.sendFile(m.chat, 'https://telegra.ph/file/60437ce6d807b605adf5e.jpg', 'zonk.jpg', `*Airdrop Ampas!* Ternyata isinya tidak sesuai ekspektasi\n\n*Rewards*\n• *Sampah:* ${sampah}\n• *Kayu:* ${kayu}\n• *Batu:* ${batu}`, m);

      u.sampah += sampah;
      u.kayu += kayu;
      u.batu += batu;
    } else if (Aku < Kamu) {
      let limit = pickRandom(['10', '20', '30']);
      let money = pickRandom(['10000', '100000', '500000']);
      let point = pickRandom(['10000', '100000', '500000']);

      kuromi.sendFile(m.chat, 'https://telegra.ph/file/d3bc1d7a97c62d3baaf73.jpg', 'rare.jpg', `*Airdrop Rare!*, Kamu mendapatkan Kotak Airdrop *Rare*\n\nSelamat kamu mendapatkan *Rewards*\n• *Limit:* ${limit}\n• *Money:* ${money}\n• *Point:* ${point}`, m);

      u.limit += parseInt(limit);
      u.money += parseInt(money);
      u.point += parseInt(point);
    } else {
      kuromi.sendFile(m.chat, 'https://telegra.ph/file/5d71027ecbcf771b299fb.jpg', 'zonk.jpg', `*Airdrop Zonks!*, Kamu mendapatkan Kotak Airdrop *Zonk (Kosong)*\n\nSelamat kamu mendapatkan *Rewards*\n• *Money:* -1.000.000\n• *Isi:* Angin`, m);
      
      u.money -= 1000000;
    }

    u.lastclaim = new Date() * 1;

    setTimeout(() => {
      kuromi.sendMessage(m.chat, { text: `Waktunya berburu *Airdrop!*` }, { quoted: m });
    }, timeout);
  }
};

// Fungsi untuk memilih nilai acak dari array
function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

// Fungsi untuk mengubah waktu menjadi format string
function clockString(ms) {
  let d = Math.floor(ms / 86400000);
  let h = Math.floor(ms / 3600000) % 24;
  let m = Math.floor(ms / 60000) % 60;
  let s = Math.floor(ms / 1000) % 60;
  return `\n*${d}* _Hari_ ☀️\n *${h}* _Jam_ 🕐\n *${m}* _Menit_ ⏰\n *${s}* _Detik_ ⏱️ `;
}