//CREATE BY REZA DEVS KUROMI
exports.run={main:async(e,{kuromi:s,store:t,groups:a,errorMessage:o})=>{s.edited=s.edited||{};try{if(a.antiedited&&"editedMessage"===e.mtype){var i=e.msg.message.protocolMessage.key;if(i){if(!s.edited[i.id]){var d=await t.loadMessage(i.remoteJid,i.id);if(!d)return;s.edited[i.id]={jid:d.key.participant,from:d.message?.extendedTextMessage?.text||d?.message?.conversation||d?.message?.imageMessage?.caption,to:e.msg.message?.protocolMessage?.editedMessage?.extendedTextMessage?.text||e.msg.message?.protocolMessage?.editedMessage?.conversation||e.msg.message?.protocolMessage?.editedMessage?.imageMessage?.caption}}var g,r,m=s.edited[i.id];m&&void 0!==m.from&&(g=e.msg.message?.protocolMessage?.editedMessage?.extendedTextMessage?.text||e.msg.message?.protocolMessage?.editedMessage?.conversation||e.msg.message?.protocolMessage?.editedMessage?.imageMessage?.caption,r=`乂  *E D I T E D - M E S S A G E*

`,r=(r+=`@${m.jid.replace(/@.+/,"")} edited the message.

`)+`➠ *From* : ${m.from}
`+"➠ *To* : "+(g!==m.to?g:m.to),s.edited[i.id].from=g,await s.reply(e.chat,r,e,{expiration:86400}))}}}catch(e){return o(e)}},group:!0,location:"plugins/event/_antiedited.js"};