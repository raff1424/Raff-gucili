//CREATE BY REZA DEVS KUROMI
let fs = require("fs"), path = require("path");

function getPathLocation(e) {
  return !!(e = e.match(/location:\s*['"]([^'"]+)['"]/)) && e[1];
}

exports.run = {
  usage: ["delplugin"],
  hidden: ["dp"],
  use: "path (atau reply plugin)",
  category: "owner",
  async: async (m, { kuromi: t, quoted: a }) => {
    if (!m.text && !m.quoted) return m.reply("Mau hapus plugin apa? Cukup kirim nama plugin-nya atau reply file plugin!");

    try {
      // Mengambil path dari teks atau reply
      let pluginPath = m.text ? m.text.trim() : getPathLocation(a ? a.text : null);

      // Jika path tidak ditemukan, cek apakah ada plugin yang di-reply
      if (!pluginPath && a) {
        if (/application\/javascript/.test(a.mime)) {
          let fileContent = await a.download();
          pluginPath = getPathLocation(fileContent.toString("utf-8"));
        }
      }

      // Jika path masih kosong, beri peringatan
      if (!pluginPath) return m.reply("Path location tidak ditemukan, masukkan path atau reply file plugin!");

      // Membuat path lengkap menuju plugin
      let fullPluginPath = path.join(process.cwd(), "plugins", pluginPath.replace(/plugins\/|\.js/g, "") + ".js");

      // Validasi jika plugin tidak ditemukan
      if (!fs.existsSync(fullPluginPath)) {
        return m.reply(`Plugin '${pluginPath}' tidak ditemukan!`);
      }

      // Menghapus plugin
      fs.unlinkSync(fullPluginPath);

      // Mengirimkan reaksi sukses
      await t.sendReact(m.chat, "✅", m.key);
    } catch (error) {
      console.log(error);
      t.sendReact(m.chat, "❌", m.key);
    }
  },
  location: "plugins/developer/delplugin.js", // Lokasi file plugin
  devs: !0
};