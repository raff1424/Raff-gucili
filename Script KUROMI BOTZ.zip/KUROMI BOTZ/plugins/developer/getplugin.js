//CREATE BY REZA DEVS KUROMI
let path = require("path"),
    fs = require("fs");

exports.run = {
  usage: ["getplugin"],
  hidden: ["gp"],
  use: "path",
  category: "owner",
  async: async (m, { kuromi, plugins }) => {
    try {
      if (!m.text)
        return m.reply(`Format salah!\nContoh : *${m.cmd} special/ping*`);
      
      let filePath = m.text.trim().toLowerCase() + ".js";
      let fullPath = path.join(process.cwd(), "plugins", filePath);
      let content = fs.readFileSync(fullPath, "utf-8");

      // Tambahkan watermark otomatis
      let watermark = `/* CODE LAIN CHEK
https://whatsapp.com/channel/0029VbARSvBCMY0PDV53rt0m
JANGAN LUPA FOLLOW
*/\n\n`;
      let result = watermark + content;

      kuromi.sendMessage(m.chat, { text: result }, { quoted: m, ephemeralExpiration: m.expiration });
    } catch (err) {
      m.reply(`Plugin '${m.text}' tidak ditemukan!\n\n` + Object.keys(plugins).map(p => p.replace("plugins/", "")).join("\n"));
    }
  },
  devs: true,
};