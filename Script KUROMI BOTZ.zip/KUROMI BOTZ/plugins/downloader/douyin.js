//CREATE BY REZA DEVS KUROMI
let axios = require("axios");

async function douyin(url) {
  try {
    const response = await axios.get(`https://api.siputzx.my.id/api/d/douyin?url=${url}`);
    const result = response.data;

    if (!result.status) throw new Error("Gagal mengambil data dari API Douyin");

    const { title, downloads } = result.data;
    const video = downloads[0];

    return {
      status: true,
      author: "@dcodekemii",
      media: {
        title,
        url: video.url
      }
    };
  } catch (e) {
    return {
      status: false,
      author: "@dcodekemii",
      message: e.message
    };
  }
}

exports.run = {
  usage: ["douyindl", "dydl"],
  hidden: ["dydl"], // alias sederhana
  use: "link douyin",
  category: "downloader",
  location: "plugins/downloader/douyin.js",
  premium: true,
  limit: true,
  async: async (m, { func, kuromi, isPrem }) => {
    const { text, command, prefix, args } = m;

    if (!text || !args[0] || !args[0].match(/douyin\.com/)) {
      return m.reply(`Masukkan URL!\n\nContoh: *${prefix}${command} https://www.douyin.com/video/7256984651137289483*`);
    }

    kuromi.sendReact(m.chat, "🕒", m.key);

    const data = await douyin(args[0]);
    if (!data.status) return m.reply(data.message);

    const caption = `*DOUYIN DOWNLOADER*\n\n- *Title* : ${data.media.title}`;

    await kuromi.sendMedia(m.chat, data.media.url, m, {
      caption,
      expiration: m.expiration
    });
  }
};