const axios = require('axios');

exports.run = {
  usage: ['pastebin'], // command utama
  hidden: [''], // command simpel
  use: 'Download isi file dari link Pastebin', // deskripsi 
  category: 'downloader', // kategori
  premium: false, // atur sesuai kebutuhan (true jika hanya untuk user premium)
  location: 'plugins/downloader/pastebin.js', // lokasi file plugin

  async: async (m, { func }) => {
    const text = m.text;
    if (!text) {
      return m.reply('*Format salah Contoh:* pastebin https://pastebin.com/xxxxxxxx');
    }

    try {
      const apiUrl = `https://fastrestapis.fasturl.cloud/downup/pastebindown?url=${encodeURIComponent(text)}`;
      const res = await axios.get(apiUrl);
      const data = res.data;

      if (!data || !data.status || !data.result || !data.result.content) {
        return m.reply('Gagal mengambil code-nya. Pastikan link benar dan Pastebin tidak di-set private.');
      }

      const pastebinContent = data.result.content.trim();
      if (!pastebinContent) {
        return m.reply('Data Pastebin kosong.');
      }

      m.reply(`📋 *Isi Pastebin:*\n\n${pastebinContent}`);
    } catch (e) {
      m.reply('ERROR: ' + e);
    }
  }
};