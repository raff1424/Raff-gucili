const axios = require('axios')
const qs = require('qs')

exports.run = {
  usage: ['tiktok'],
  hidden: ['tt'],
  use: 'link tiktok',
  category: 'downloader',
  async: async (m, { func, kuromi }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'https://vt.tiktok.com/ZSF4cWcA2/'))
    if (!m.args[0].includes('tiktok.com')) return m.reply(global.mess.error.url)

    kuromi.sendReact(m.chat, '🕒', m.key)

    try {
      const { data } = await axios.post(
        'https://tikwm.com/api/',
        qs.stringify({
          url: m.args[0],
          count: 12,
          cursor: 0,
          web: 1,
          hd: 1
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'X-Requested-With': 'XMLHttpRequest',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
            'Referer': 'https://tikwm.com/'
          }
        }
      )

      if (data.code !== 0) return m.reply('Gagal mengambil data dari TikTok.')

      const result = data.data

      let txt = '乂  *TIKTOK - DOWNLOADER*\n'
      txt += `\n◦ *Title* : ${result.title}`
      txt += `\n◦ *User* : ${result.author.nickname} (@${result.author.unique_id})`
      txt += `\n◦ *Durasi* : ${result.duration}s`
      txt += `\n◦ *Likes* : ${result.digg_count.toLocaleString()}`
      txt += `\n◦ *Views* : ${result.play_count.toLocaleString()}`
      txt += `\n◦ *Shares* : ${result.share_count.toLocaleString()}`
      txt += `\n◦ *Comments* : ${result.comment_count.toLocaleString()}`
      txt += `\n◦ *Download* : Tanpa Watermark`

      await kuromi.sendMessage(m.chat, {
        video: { url: 'https://tikwm.com' + result.play },
        caption: txt
      }, { quoted: m, ephemeralExpiration: m.expiration })

    } catch (err) {
      console.error(err)
      m.reply('Maaf, terjadi kesalahan saat memproses video.')
    }
  },
  limit: 5
}