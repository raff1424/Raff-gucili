// CREATE BY REZA DEVS KUROMI
let axios = require("axios"), yts = require("yt-search");
let processedAudio = new Set;
let chatId = "120363375725098747@newsletter"; // GANTI dengan ID channel kamu

async function getBuffer(url) {
  try {
    const res = await axios.get(url, { responseType: "arraybuffer" });
    return Buffer.from(res.data, "binary");
  } catch (err) {
    console.error("Error fetching buffer:", err);
    return null;
  }
}

exports.run = {
  usage: ["play4"],
  use: "judul lagu",
  category: "downloader",
  async: async (m, { func, kuromi, users }) => {
    if (!m.text) return m.reply(func.example(m.cmd, "melukis senja"));

    const query = m.text.trim();
    if (processedAudio.has(query)) return m.reply("Masih ada proses yang belum selesai.");
    processedAudio.add(query);

    kuromi.sendReact(m.chat, "🕒", m.key);

    try {
      let yt = (await yts(query)).videos[0];
      if (!yt) throw new Error("Video tidak ditemukan.");

      const duration = (yt.timestamp || yt.duration?.timestamp || "0:00")
        .split(":").reduce((a, b) => 60 * a + +b, 0);
      if (duration >= 3600) return m.reply("Video lebih dari 1 jam.");

      let caption = `*Y O U T U B E - P L A Y*\n
∘ Title : ${yt.title}
∘ Duration : ${yt.timestamp}
∘ Views : ${yt.views}
∘ Upload : ${yt.ago}
∘ Author : ${yt.author?.name}
∘ URL : ${yt.url}

Audio akan segera dikirim ke Channel...`;

      const thumb = await getBuffer(yt.thumbnail);
      const quotedMsg = await kuromi.sendMessage(m.chat, { image: thumb, caption }, { quoted: m });

      const videoId = yt.url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];

      const headers = {
        accept: "*/*",
        "accept-language": "id-ID,id;q=0.9",
        "sec-ch-ua": '"Not A(Brand";v="8", "Chromium";v="132"',
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": '"Android"',
        Referer: "https://id.ytmp3.mobi/",
      };

      const init = await fetch("https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=" + Math.random(), { headers });
      const initData = await init.json();
      const convertUrl = `${initData.convertURL}&v=${videoId}&f=mp3&_=${Math.random()}`;
      const convert = await (await fetch(convertUrl, { headers })).json();

      let progress = {};
      for (let i = 0; i < 3; i++) {
        const status = await fetch(convert.progressURL, { headers });
        progress = await status.json();
        if (progress.progress === 3) break;
        await new Promise(r => setTimeout(r, 1500));
      }

      const audioUrl = convert.downloadURL;

      // Kirim ke CHANNEL untuk SEMUA USER, tanpa ptt agar bisa diputar
      try {
        await kuromi.sendMessage(chatId, {
          audio: { url: audioUrl },
          mimetype: "audio/mpeg",
          fileName: yt.title + ".mp3"
        });

        await kuromi.sendMessage(chatId, {
          text: yt.title,
          contextInfo: {
            externalAdReply: {
              title: "Request from " + users.name,
              body: global.header,
              thumbnail: thumb,
              mediaType: 1,
              previewType: "PHOTO",
              mediaUrl: yt.url,
              sourceUrl: yt.url,
              renderLargerThumbnail: false
            }
          }
        });

        await m.reply(`Lagu berhasil dikirim ke channel!\nCek: https://whatsapp.com/channel/0029VayyRfQ2ZjCmo4exLd2a`, quotedMsg);
      } catch (err) {
        console.error("Gagal kirim ke channel:", err);
        await m.reply("Gagal kirim ke channel. Pastikan bot admin & sudah join channel.");
      }

    } catch (err) {
      console.error("Error:", err);
      m.reply(err.message || "Terjadi kesalahan.");
    } finally {
      processedAudio.delete(query);
    }
  },
  restrict: true,
  limit: 3,
  location: "plugins/downloader/play4.js"
};