//CREATE BY REZA DEVS KUROMI
exports.run={usage:["mediafire"],hidden:["mfire","mfdl"],use:"link mediafire",category:"downloader",async:async(e,{func:i,kuromi:a})=>{var t;return e.text?e.args[0].includes("mediafire.com")?(a.sendReact(e.chat,"🕒",e.key),(i=await i.fetchJson("https://api.siputzx.my.id/api/d/mediafire?url="+e.args[0])).status?(i=i?.data)?.fileName?(t=`乂  *AUTO MEDIAFIRE DOWNLOADER*
`,t+=`
◦ File Name: `+i.fileName,a.sendMessage(e.chat,{text:t+`
◦ File Size: `+i.fileSize+`

_Please wait media is being sent..._`},{quoted:e,ephemeralExpiration:e.expiration}),void await a.sendMedia(e.chat,i.downloadLink,e,{caption:global.mess.ok,fileName:i.fileName,expiration:e.expiration})):e.reply("Linknya gak ada kocak!"):e.reply("Something when wrong!")):e.reply(global.mess.error.url):e.reply(i.example(e.cmd,"https://www.mediafire.com/file/a61862y1tgvfiim/ZackBotMans+(+Versi+1.0.1+).zip/file"))},limit:3,location:"plugins/downloader/mediafire.js"};