//CREATE BY REZA DEVS KUROMI
let axios=require("axios");async function terabox(e){try{var a=await axios.get("https://tera.instavideosave.com/?url="+encodeURIComponent(e),{headers:{"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"}});return a.data.video&&0<a.data.video.length?{status:!0,data:a.data.video[0]}:{status:!1,message:"No video data found in the response"}}catch(e){return console.error("Error fetching data from terabox:",e),{status:!1,message:"Error fetching data from terabox",error:e.message||"Unknown Error",stack:e.stack||"No stack trace available",statusCode:e.response?e.response.status:"N/A",headers:e.response?JSON.stringify(e.response.headers):"N/A"}}}exports.run={usage:["terabox"],hidden:["teraboxdl"],use:"link terabox",category:"downloader",async:async(e,{func:a,kuromi:r,command:t})=>{if(!e||!e.text)return e.reply(a.example(t,"link"));try{e.reply(global.mess.wait);var s,o,n,i=await terabox(e.text);i.status?({video:s,thumbnail:o}=i.data,o&&await r.sendMessage(e.chat,{image:{url:o}},{quoted:e}),s&&await r.sendMessage(e.chat,{video:{url:s},caption:"Here is your video"},{quoted:e}),await r.sendReact(e.chat,"✅",e.key)):(n=`Internal Error: ${i.message}

`+`Error Details: ${i.error}
`+`Status Code: ${i.statusCode}
`+`Headers: ${i.headers}
`+"Stack Trace: "+i.stack,e.reply(n))}catch(r){console.error("Error:",r),a=`Internal Error: ${r.message||"Unknown Error"}

`+"Full Error: "+JSON.stringify(r,null,2),e.reply(a)}},premium:!0,limit:3};