const axios = require('axios');
const qs = require('qs');
const cheerio = require('cheerio');

async function xx(url) {
  try {
    const userverifyRes = await axios.post(
      'https://x2twitter.com/api/userverify',
      qs.stringify({ url }),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Accept': '*/*',
          'X-Requested-With': 'XMLHttpRequest',
        }
      }
    );

    const token = userverifyRes.data.token;
    if (!token) throw new Error('Token not found');

    const ajaxSearchRes = await axios.post(
      'https://x2twitter.com/api/ajaxSearch',
      qs.stringify({
        q: url,
        lang: 'id',
        cftoken: token
      }),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Accept': '*/*',
          'X-Requested-With': 'XMLHttpRequest',
        }
      }
    );

    const htmlData = ajaxSearchRes.data.data;
    const $ = cheerio.load(htmlData);
    const results = [];

    $('.tw-button-dl').each((i, el) => {
      const text = $(el).text().trim();
      const href = $(el).attr('href');
      if (href && text.includes('Unduh') && text.includes('720')) {
        results.push({
          label: text,
          url: href
        });
      }
    });

    return results;
  } catch (e) {
    return [];
  }
}

exports.run = {
  usage: ['twitter'],
  use: 'url',
  category: 'downloader',
  async: async (m, { func, args, kuromi, mess }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'https://x.com/username/status/1234567890123456789'))
    if (!m.args[0].includes('x.com') && !m.args[0].includes('twitter.com')) return m.reply(mess.error.url)
    kuromi.sendReact(m.chat, '🕒', m.key)

    await xx(m.args[0]).then(async (data) => {
      if (!data.length) return m.reply('Gagal mendapatkan video 720p atau tidak tersedia.')
      for (let i of data) {
        await func.delay(1000)
        await kuromi.sendMedia(m.chat, i.url, m, {
          caption: `◦ 720p Video\n◦ Label: ${i.label}`,
          expiration: m.expiration
        });
      }
    })
  },
  limit: 5
}