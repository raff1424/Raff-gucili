const axios = require('axios');
const cheerio = require('cheerio');

async function scrapeVideoInfo(url) {
  try {
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    const downloadLink = $('a#tracking-url').attr('href');
    const downloadTitle = $('a#tracking-url').attr('title');
    const category = $('a.label').first().text().trim();
    const categoryUrl = $('a.label').first().attr('href');
    const thumbnail = $('video, img').first().attr('poster') || $('[data-thumbs]').attr('data-thumbs');

    return {
      title: downloadTitle || 'DOSA GOBLOK',
      download: downloadLink || 'haram bodoh',
      category: category || 'Yatim ngebokep terus kasian ga ada',
      categoryUrl: categoryUrl || 'YAHAHAH GA ADA',
      thumbnail: thumbnail || 'WADU GA ADA CO',
    };
  } catch (e) {
    return e.message;
  }
}

exports.run = {
  usage: ['bokepidetail'],
  hidden: ['bokepdl'],
  use: 'link',
  category: 'downloader',
  async: async (m, { kuromi }) => {
    if (!m.text || !/^https:\/\/bokepi\.com\//.test(m.text)) return m.reply('Masukkan link dari bokepi.com\nContoh: bokepidetail https://bokepi.com/xxx');

    try {
      const videoInfo = await scrapeVideoInfo(m.text);
      
      if (videoInfo instanceof Error) {
        return m.reply('Gagal mengambil detail video.');
      }

      const { title, download, category, categoryUrl, thumbnail } = videoInfo;

      const caption = `*${title}*\n\nLink download:\n${download}\nKategori: ${category}\nLink kategori: ${categoryUrl}`;
      await kuromi.sendMessage(m.chat, {
        image: { url: thumbnail },
        caption: caption
      }, { quoted: m });
    } catch (err) {
      m.reply('Gagal mengambil detail video.');
    }
  },
  location: "plugins/downloader/bokepidetail.js"
}