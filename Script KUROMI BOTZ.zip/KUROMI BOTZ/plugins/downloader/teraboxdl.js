//CREATE BY REZA DEVS KUROMI
let axios=require("axios");exports.run={usage:["terabox"],hidden:["tbxdl"],use:"link terabox",category:"downloader",async:async(e,{func:r,kuromi:a})=>{if(!e.text)return e.reply(r.example(e.cmd,"link"));a.sendReact(e.chat,"🕒",e.key);try{var t="https://tera.instavideosave.com/?url="+encodeURIComponent(e.text);await a.sendMessage(e.chat,"Here is your download link: "+t),await a.sendReact(e.chat,"✅",e.key)}catch(a){console.error("Error:",a),r=a.message||String(a),e.reply(`Internal Error: ${r}

Full Error: `+JSON.stringify(a,null,2))}},premium:!0,limit:3};