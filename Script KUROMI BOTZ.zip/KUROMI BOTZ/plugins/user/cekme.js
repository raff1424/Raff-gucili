//CREATE BY REZA DEVS KUROMI
exports.run={usage:["cekme","apakah","bisakah","kapankah","bagaimanakah","rate","gantengcek","cantikcek","sangecek","gaycek","lesbicek"],category:"user",async:async(a,{func:e,kuromi:n,froms:i})=>{switch(a.command){case"cekme":var t=["Cakep ✅","Jelek Anjrit ❌"],r=["Pembohong","Galak","Suka Bantu Orang","Baik","Jahat:(","Bobrok","Suka BadMood","Setia","Tulus","Beriman","Penyayang Binatang","Baperan"],g=["Makan","Tidur","Main Game","Sesama Jenis","Binatang",`Seseorang Yang ${a.pushname} Sukai`,"Belajar","Ibadah","Diri Sendiri"],o=["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","31","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59","60","61","62","63","64","65","66","67","68","69","70","71","72","73","74","75","76","77","78","79","80","81","82","82","84","84","86","87","88","89","90","91","92","93","94","95","96","97","98","99","100"],t=t[Math.floor(Math.random()*t.length)],r=r[Math.floor(Math.random()*r.length)],g=g[Math.floor(Math.random()*g.length)],l=o[Math.floor(Math.random()*o.length)],u=o[Math.floor(Math.random()*o.length)],o=o[Math.floor(Math.random()*o.length)],r=`乂  *CEK PRIBADI KAMU*

Nama : ${a.pushname}
Sifat : ${a.sender==global.owner?"Setia":r}
Keberanian : ${u}%
Ketakutan : ${l}%
Cakep : ${a.sender==global.owner?"Cakep ✅":t}
Cek Pintar : ${o}%
Menyukai : `+g;n.sendMessage(a.chat,{text:r},{quoted:a,ephemeralExpiration:a.expiration});break;case"apakah":if(!a.text)return a.reply(`Gunakan dengan cara ${a.cmd} text

Contoh : ${a.cmd} kamu lonteh`);a.reply(`Pertanyaan : apakah ${a.text}
Jawaban : `+(u=["Iya","Tidak","Bisa Jadi","Betul","Bisa Jadi Tidak"]).random());break;case"bisakah":if(!a.text)return a.reply(`Gunakan dengan cara ${a.cmd} text

Contoh : ${a.cmd} saya punya cewe`);a.reply(`Pertanyaan : bisakah ${a.text}
Jawaban : `+(l=["Bisa","Gak Bisa","Gak Bisa Ajg Awokwokak","TENTU PASTI KAMU BISA!!!!","TENTU, PASTI KAMU *TIDAK* BISA!!"]).random());break;case"kapankah":if(!a.text)return a.reply(`Gunakan dengan cara ${a.cmd} Pertanyaan

Contoh : ${a.cmd} saya punya cewe`);a.reply(`Pertanyaan : kapankah ${a.text}
Jawaban : *${(t=["5 Hari Lagi","10 Hari Lagi","15 Hari Lagi","20 Hari Lagi","25 Hari Lagi","30 Hari Lagi","35 Hari Lagi","40 Hari Lagi","45 Hari Lagi","50 Hari Lagi","55 Hari Lagi","60 Hari Lagi","65 Hari Lagi","70 Hari Lagi","75 Hari Lagi","80 Hari Lagi","85 Hari Lagi","90 Hari Lagi","100 Hari Lagi","5 Bulan Lagi","10 Bulan Lagi","15 Bulan Lagi","20 Bulan Lagi","25 Bulan Lagi","30 Bulan Lagi","35 Bulan Lagi","40 Bulan Lagi","45 Bulan Lagi","50 Bulan Lagi","55 Bulan Lagi","60 Bulan Lagi","65 Bulan Lagi","70 Bulan Lagi","75 Bulan Lagi","80 Bulan Lagi","85 Bulan Lagi","90 Bulan Lagi","100 Bulan Lagi","1 Tahun Lagi","2 Tahun Lagi","3 Tahun Lagi","4 Tahun Lagi","5 Tahun Lagi","Besok","Lusa","Abis Ini Juga Lu "+a.text]).random()}*`);break;case"bagaimanakah":if(!a.text)return a.reply(`Gunakan dengan cara ${a.cmd} text

Contoh : ${a.cmd} cara punya cewe`);a.reply(`Pertanyaan : bagaimanakah ${a.text}
Jawaban : `+(o=["Ga Gimana2","Sulit Itu Bro","Maaf Bot Tidak Bisa Menjawab","Coba Deh Cari Di Gugel","Astaghfirallah Beneran???","Pusing ah","Ooh Gitu","Yang Sabar Ya Bos","Gimana yeee"]).random());break;case"rate":if(!a.text)return a.reply(`Gunakan dengan cara ${a.cmd} text

Contoh : ${a.cmd} kebesaran tytydku`);g=Math.floor(100*Math.random()),a.reply(`Rate : ${a.text}
Jawaban : *${+g}%*`);break;case"gantengcek":case"cantikcek":case"sangecek":case"gaycek":case"lesbicek":if(!i)return a.reply(`Gunakan dengan cara ${a.cmd} @tag

Contoh : ${a.cmd} @⁨0`);r=Math.floor(100*Math.random()),/gaycek/.test(a.command)?(n.sendReact(a.chat,"🕒",a.key),u=global.db.users[i],l=await n.profilePictureUrl(i,"image").catch(a=>"https://files.catbox.moe/39hmb8.jpg"),o=/files\.catbox\.moe/.test(l)?l:await e.tmpfiles(await e.fetchBuffer(l)),t=`https://api.siputzx.my.id/api/canvas/gay?nama=${u.name}&avatar=${o}&num=`+r,await n.sendMedia(a.chat,t,a,{expiration:a.expiration})):a.reply(`Nama : @${i.split("@")[0]}
Jawaban : *${r}%*`)}},limit:!0,location:"plugins/user/cekme.js"};