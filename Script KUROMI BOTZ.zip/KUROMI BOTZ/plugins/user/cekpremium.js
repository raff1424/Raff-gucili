//CREATE BY REZA DEVS KUROMI
exports.run={usage:["cekpremium"],hidden:["cekprem"],category:"user",async:async(e,{func:r,kuromi:m,users:i})=>{if(!i.premium)return e.reply(`Kamu bukan pengguna premium. kirim ${e.prefix}buyprem untuk melihat list harga premium.`);var p="乂  *C E K - P R E M I U M*\n\n",p=(p+=`◦  *ID* : @${e.sender.split("@")[0]}
`)+`◦  *Name* : ${i.name}
`+"◦  *Expire* : "+("PERMANENT"!=i.expired.premium?r.expireTime(i.expired.premium):"PERMANENT");m.reply(e.chat,p,e)}};