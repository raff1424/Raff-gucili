//CREATE BY REZA DEVS KUROMI
exports.run={usage:["jodohku"],category:"user",async:async(t,{})=>{if(t.isGc){var a=(a=t.members.filter(a=>a.id!==t.sender).map(a=>a.id))[Math.floor(Math.random()*a.length)];t.reply(`👫Jodoh mu adalah

@${t.sender.split("@")[0]} ❤️ @`+a.split("@")[0])}else if(t.isPc){a=Object.values(global.db.metadata);let e=[];a.map(({participants:a})=>a.filter(a=>a.id!==t.sender).map(a=>a.id)).map(a=>e.push(...a)),a=e[Math.floor(Math.random()*e.length)],t.reply(`👫Jodoh mu adalah

@${t.sender.split("@")[0]} ❤️ @`+a.split("@")[0])}},limit:!0};