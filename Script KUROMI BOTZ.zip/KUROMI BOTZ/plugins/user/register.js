//CREATE BY REZA DEVS KUROMI
let phoneNumber=require("awesome-phonenumber"),fs=require("fs"),fetch=require("node-fetch");exports.run={usage:["register"],hidden:["daftar"],category:"user",async:async(e,{kuromi:a,users:r})=>{if(a.registered=a.registered||{},r.register)return e.reply("Nomor kamu sudah terverifikasi.");if(void 0!==a.registered[e.sender])return e.reply("Selesaikan register mu yang sebelumnya!");try{var n=(await a.reply(e.chat,`Silahkan ketik nama kamu
Contoh: Reza
- gunakan data asli agar terhindar dari banned.`,e,{expiration:e.expiration})).key;a.registered[e.sender]={id:e.sender,key:n,sesi:"name",name:"-",age:"-",gender:"-"}}catch(r){a.registered[e.sender],delete a.registered[e.sender],a.reply(e.chat,`Something went wrong: ${r.message}
please try again.`,e,{expiration:e.expiration})}},main:async(a,{func:e,kuromi:r,users:n,calender:i})=>{if(r.registered=r.registered||{},n&&!n.register&&r.registered[a.sender]&&!a.fromMe){console.log(a.message);var t=r.registered[a.sender];if(/name/.test(t.sesi))return a.budy?a.isPrefix?a.reply(`Nama tidak boleh menggunakan awalan ( ${a.prefix} )`):(t.name=e.toFirstCase(a.budy),t.sesi="age",void await r.reply(a.chat,`Silahkan ketik umur kamu
Contoh: 19
- gunakan data asli agar terhindar dari banned.`,a,{expiration:a.expiration})):a.reply("Mohon masukkan keyword yang benar.");if(/age/.test(t.sesi))return!a.budy||a.isPrefix?a.reply("Mohon masukkan keyword yang benar."):isNaN(a.budy)?a.reply(`Umur harus berupa angka!
Contoh: 19`):60<Number(a.budy)?(global.db.users[t.id].banned=!0,global.db.users[t.id].expired.banned="PERMANENT",delete r.registered[t.id],a.reply("Maaf umur Anda terlalu tua untuk bisa menggunakan bot ini.\nSystem bot kami telah memblokir akun anda dengan alasan *old age.*\n\nJika ingin membuka banned akan dikenakan biaya sebesar Rp. 5.000.")):Number(a.budy)<6?a.reply("Bayi bisa ngetik sesuai format bjir ._."):Number(a.budy)<12?(global.db.users[t.id].banned=!0,global.db.users[t.id].expired.banned="PERMANENT",delete r.registered[t.id],a.reply("Anda belum cukup umur untuk bisa menggunakan bot ini.\nSystem bot kami telah memblokir akun anda dengan alasan *child age.*\n\nJika ingin membuka banned akan dikenakan biaya sebesar Rp. 5.000.")):(t.age=Number(parseInt(a.budy)),t.sesi="gender",void await r.sendbut(a.chat,"Silahkan pilih jenis kelamin kamu","_Male untuk Laki-laki & Female untuk Perempuan_\n- gunakan data asli agar terhindar dari banned",[["Male","male"],["Female","female"]],a,{expiration:a.expiration}));if(/gender/.test(t.sesi)){if(!a.budy)return a.reply("Mohon masukkan keyword yang benar.");if(a.isPrefix)return a.reply("Mohon masukkan keyword yang benar.");if(/^male$/i.test(a.budy))t.gender="Laki-laki";else{if(!/^female$/i.test(a.budy))return a.reply(`Mohon masukkan keyword yang benar!
ketik *male* untuk Laki-laki
ketik *female* untuk Perempuan`);t.gender="Perempuan"}var{name:t,age:s,gender:d}=t,u=phoneNumber("+"+a.sender.replace("@s.whatsapp.net","")).getNumber("international"),i=`*✅ VERIFICATION SUCCESSFULLY*

» Name : ${t}
» Age : ${s}
» Gender : ${d}
» Number : ${u}
» Date : ${i+(n.registergift?"":"\n» Limit : +35")}

- kirim \`${a.prefix}unreg\` jika data yang anda masukkan salah.`,n=(n.name=t,n.age=s,n.gender=d,n.register=!0,n.registergift||(n.limit+=35),n.registergift=!0,`Users Registered

Name : ${t}
Age : ${s}
Gender : ${d}
Number : `+u);await r.reply(a.chat,i,e.fverified,{expiration:a.expiration}).then(e=>delete r.registered[a.sender]),global.devs.includes(a.sender)||await r.sendMessage(global.owner,{document:fs.readFileSync("./database/database.json"),caption:n,mimetype:"application/json",fileName:"database.json"},{quoted:e.fverified,ephemeralExpiration:0})}}},private:!0,location:"plugins/user/register.js"};