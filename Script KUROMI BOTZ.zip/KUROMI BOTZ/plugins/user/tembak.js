//CREATE BY REZA DEVS KUROMI
exports.run={usage:["tembak"],use:"mention or reply",category:"user",async:async(a,{froms:e})=>{if(a.quoted||a.text){if(void 0===global.db.users[e])return a.reply("User data not found.");var n=global.db.users[a.sender].pasangan.id;if(e===a.sender)return a.reply("Tidak bisa berpacaran dengan diri sendiri!");if(e===a.bot)return a.reply("Tidak bisa berpacaran dengan bot!");if(""==global.db.users[a.sender].gender)return a.reply(`Kamu belum memilih gender!
kirim perintah *${a.prefix}gender male / female*`);if(""==global.db.users[e].gender)return a.reply(`@${e.split("@")[0]} belum memilih gender!
kirim perintah *${a.prefix}gender male / female*`);if("Perempuan"==global.db.users[a.sender].gender&&"Perempuan"==global.db.users[e].gender)return a.reply(`Tidak bisa tembak @${e.split("@")[0]} karena kalian *LESBI*`);if("Laki-laki"==global.db.users[a.sender].gender&&"Laki-laki"==global.db.users[e].gender)return a.reply(`Tidak bisa tembak @${e.split("@")[0]} karena kalian *GAY*`);if(""!=global.db.users[a.sender].pasangan.id&&global.db.users[global.db.users[a.sender].pasangan.id].pasangan.id==a.sender&&global.db.users[a.sender].pasangan.id!=e){if(global.db.users[a.sender].pasangan.id==e)return a.reply("Kamu sudah berpacaran dengan dia!");a.reply(`Kamu sudah berpasangan dengan @${global.db.users[a.sender].pasangan.id.split("@")[0]}

Putusin dulu! kirim ${a.prefix}putus @${global.db.users[a.sender].pasangan.id.split("@")[0]} untuk menembak @${e.split("@")[0]}

Setia dong!`)}else if(""!=global.db.users[e].pasangan.id){var r=global.db.users[e].pasangan.id;if(global.db.users[r].pasangan.id==e){if(a.sender==r&&global.db.users[a.sender].pasangan.id==e)return a.reply(`Kamu sudah berpasangan dengan @${n.split("@")[0]}

Setia dong!`);a.reply(`Tau sopan santun dikit teman?
@${e.split("@")[0]} sudah berpasangan dengan @${r.split("@")[0]}

Silahkan cari pasangan yang lain!`)}else global.db.users[a.sender].pasangan.id=e,a.reply(`Kamu sudah mengajak @${e.split("@")[0]} berpacaran!
kamu hanya perlu menunggu jawaban dari dia...

@${e.split("@")[0]} silahkan ketik
${a.prefix}terima @${a.sender.split("@")[0]} atau
${a.prefix}tolak @`+a.sender.split("@")[0])}else global.db.users[e].pasangan.id==a.sender?(global.db.users[a.sender].pasangan.id=e,global.db.users[a.sender].pasangan.time=+Date.now(),global.db.users[e].pasangan.time=+Date.now(),a.reply(`Selamat! kamu resmi berpacaran dengan @${e.split("@")[0]}

Semoga kalian bisa ke jenjang yang lebih serius 🥳🥳`)):(global.db.users[a.sender].pasangan.id=e,a.reply(`Kamu baru saja mengajak @${e.split("@")[0]} berpacaran

@${e.split("@")[0]} Silahkan ketik
${a.prefix}terima @${a.sender.split("@")[0]} atau
${a.prefix}tolak @`+a.sender.split("@")[0]))}else a.reply("Mention or Reply chat target.")},group:!0};