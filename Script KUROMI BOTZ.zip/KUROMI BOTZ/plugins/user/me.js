//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch"),ms=require("parse-ms");function timeReverse(e){return(e=ms(Date.now()-e)).days+`D ${e.hours}H ${e.minutes}M ${e.seconds}S`}exports.run={usage:["me"],category:"user",async:async(e,{func:a,kuromi:n})=>{n.sendReact(e.chat,"🕒",e.key),void 0===global.db.users[global.db.users[e.sender].pasangan.id]&&(global.db.users[e.sender].pasangan.id="");var{name:r,gender:t,age:i,limit:s,balance:d,premium:l,banned:o,jadibot:m,warning:c,register:g,date:u,pasangan:h,expired:p,level:b,exp:E,role:N,currentWorld:$,inventory:k}=global.db.users[e.sender],R=`@${h.id.split("@")[0]} (${timeReverse(h.time)})`,R=h.id?global.db.users[h.id].pasangan.id?R:"Sedang digantung @"+h.id.split("@")[0]:"Jomblo Abadi";try{var v=(await n.fetchStatus(e.sender).catch(e=>{})||{}).status||""}catch{v="-"}var h=await n.fetchBlocklist().catch(e=>[]),f=k&&(k.katalis_sculk||k.nether_star||k.ender_egg);let w=`乂  *U S E R - P R O F I L E*

◈ *Name* : ${r||e.pushname}
◈ *Gender* : ${t||"-"}
◈ *Age* : ${i||"-"}
◈ *Limit* : ${l?"Unlimited":s}
◈ *Balance* : ${a.formatNumber(d)}
◈ *Level* : ${b}
◈ *Exp* : ${E} / ${10*Math.pow(b,2)+50*b+100}
◈ *Role* : ${N}
◈ *Lovers* : ${R}
◈ *About* : ${v||"-"}

乂  *U S E R - S T A T U S*
${$?"\n◈ *Current World* : "+$:""}
◈ *Warning* : ${c} / 3
◈ *Blocked* : ${h.includes(e.sender)?"Yes":"No"}
◈ *Banned* : ${o?"Yes ("+("PERMANENT"==p.banned?"PERMANENT":a.timeReverse(p.banned))+")":"No"}
◈ *Premium* : ${l?"Yes ("+("PERMANENT"==p.premium?"PERMANENT":a.timeReverse(p.premium))+")":"No"}
◈ *Jadibot* : ${m?"Yes ("+("PERMANENT"==p.jadibot?"PERMANENT":a.timeReverse(p.jadibot))+")":"No"}
◈ *Register* : `+(g?"Yes ("+u+")":"No");f&&(w+="\n\n乂  *A C H I E V E M E N T*",0<k.katalis_sculk&&(w+="\n\n- mendapatkan item special `Katalis Sculk` karena berhasil mengalahkan *Worden* di Overworld"),0<k.nether_star&&(w+="\n\n- mendapatkan item special `Nether Star` karena berhasil mengalahkan *Wither* di Netherworld"),0<k.ender_egg)&&(w+="\n\n- mendapatkan item special `Ender Egg` karena berhasil mengalahkan *Ender Dragon* di The End.");try{var A=await n.profilePictureUrl(e.sender,"image").catch(e=>"https://files.catbox.moe/39hmb8.jpg");await n.sendMessageModify(e.chat,w,e,{largeThumb:!0,thumbnail:await(await fetch(A)).buffer(),expiration:e.expiration})}catch(a){console.log(a),n.reply(e.chat,w,e,{expiration:e.expiration})}},location:"plugins/user/me.js"};