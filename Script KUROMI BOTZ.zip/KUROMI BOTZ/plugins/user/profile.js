//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch"),ms=require("parse-ms");function timeReverse(e){return(e=ms(Date.now()-e)).days+`D ${e.hours}H ${e.minutes}M ${e.seconds}S`}exports.run={usage:["profile"],hidden:["profil"],use:"mention or reply",category:"user",async:async(a,{func:r,kuromi:n,froms:t})=>{if(a.quoted||a.text){if(void 0===global.db.users[t])return a.reply("User data not found.");n.sendReact(a.chat,"🕒",a.key),null==global.db.users[global.db.users[t].pasangan.id]&&(global.db.users[t].pasangan.id="");var{name:i,gender:s,age:l,limit:o,balance:d,premium:m,banned:u,jadibot:c,warning:g,register:p,date:h,pasangan:b,expired:E,level:N,exp:$,role:f,currentWorld:R,inventory:k}=global.db.users[t],v=`@${b.id.split("@")[0]} (${timeReverse(b.time)})`,v=b.id?global.db.users[b.id].pasangan.id?v:"Sedang digantung @"+b.id.split("@")[0]:"Jomblo Abadi";try{var y=(await n.fetchStatus(t).catch(e=>{})||{}).status||""}catch{y="-"}var b=await n.fetchBlocklist().catch(e=>[]),M=k&&(k.katalis_sculk||k.nether_star||k.ender_egg);let e=`乂  *U S E R - P R O F I L E*

◈ *Name* : ${i||a.pushname}
◈ *Gender* : ${s||"-"}
◈ *Age* : ${l||"-"}
◈ *Limit* : ${m?"Unlimited":o}
◈ *Balance* : ${r.formatNumber(d)}
◈ *Level* : ${N}
◈ *Exp* : ${$} / ${10*Math.pow(N,2)+50*N+100}
◈ *Role* : ${f}
◈ *Lovers* : ${v}
◈ *About* : ${y||"-"}

乂  *U S E R - S T A T U S*
${R?"\n◈ *Current World* : "+R:""}
◈ *Warning* : ${g} / 3
◈ *Blocked* : ${b.includes(t)?"Yes":"No"}
◈ *Banned* : ${u?"Yes ("+("PERMANENT"==E.banned?"PERMANENT":r.timeReverse(E.banned))+")":"No"}
◈ *Premium* : ${m?"Yes ("+("PERMANENT"==E.premium?"PERMANENT":r.timeReverse(E.premium))+")":"No"}
◈ *Jadibot* : ${c?"Yes ("+("PERMANENT"==E.jadibot?"PERMANENT":r.timeReverse(E.jadibot))+")":"No"}
◈ *Register* : `+(p?"Yes ("+h+")":"No");M&&(e+="\n\n乂  *A C H I E V E M E N T*",0<k.katalis_sculk&&(e+="\n\n- mendapatkan item special `Katalis Sculk` karena berhasil mengalahkan *Worden* di Overworld"),0<k.nether_star&&(e+="\n\n- mendapatkan item special `Nether Star` karena berhasil mengalahkan *Wither* di Netherworld"),0<k.ender_egg)&&(e+="\n\n- mendapatkan item special `Ender Egg` karena berhasil mengalahkan *Ender Dragon* di The End.");try{var w=await n.profilePictureUrl(t,"image").catch(e=>"https://files.catbox.moe/39hmb8.jpg");await n.sendMessageModify(a.chat,e,a,{largeThumb:!0,thumbnail:await(await fetch(w)).buffer(),expiration:a.expiration})}catch(r){console.log(r),n.reply(a.chat,e,a,{expiration:a.expiration})}}else a.reply("Mention or Reply chat target.")},group:!0,location:"plugins/user/profile.js"};