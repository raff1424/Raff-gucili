//CREATE BY REZA DEVS KUROMI
exports.run={usage:["gender"],use:"male / female",category:"user",async:async(e,{})=>{if(""!==global.db.users[e.sender].gender)return e.reply("Kamu sudah memiliki gender!");/^(male)$/i.test(e.args[0])?(global.db.users[e.sender].gender="Laki-laki",e.reply("Kamu telah memilih jenis kelamin `Laki-laki`.")):/^(female)$/i.test(e.args[0])?(global.db.users[e.sender].gender="Perempuan",e.reply("Kamu telah memilih jenis kelamin `Perempuan`.")):e.reply(`Mohon masukkan keyword dengan benar!
Contoh: ${e.prefix}gender male

${e.prefix}gender male untuk \`Laki-laki\`.
${e.prefix}gender female untuk \`Perempuan\`.`)}};