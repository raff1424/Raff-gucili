/* 
 * Fitur untuk menampilkan daftar anime populer dari Anichin
 * API: https://api.siputzx.my.id/api/anime/anichin-popular
 * JANGAN LUPA FOLLOW: https://whatsapp.com/channel/0029VbARSvBCMY0PDV53rt0m
 */

exports.run = {
  usage: ['anichinpopuler'],
  use: 'menampilkan daftar anime populer dari Anichin',
  category: 'anime',
  async: async (m, { kuromi, func }) => {
    m.reply('TUNGGU SEBENTAR KAK, 5 DETIK AJA');

    let res = await fetch('https://api.siputzx.my.id/api/anime/anichin-popular');
    let json;

    try {
      json = await res.json();
    } catch (error) {
      return m.reply('Terjadi kesalahan dalam memproses data dari API.');
    }

    if (!json || !json.status || !json.data || !Array.isArray(json.data) || json.data.length === 0) {
      return m.reply('Data tidak ditemukan atau terjadi kesalahan saat memproses data.');
    }

    const list = json.data.slice(0, 5); // Batasi hingga 5 item untuk menghindari spam
    for (let i = 0; i < list.length; i++) {
      const item = list[i];
      if (!m.chat) return m.reply('Terjadi masalah dengan chat, tidak dapat mengirim pesan.');

      await func.delay(5000); // Delay 5 detik antar pesan

      await kuromi.sendMessage(
        m.chat,
        {
          image: { url: item.image },
          caption: `*Anime Populer ke-${i + 1} dari ${list.length}*\n\n*Judul:* ${item.title}\n*Episode:* ${item.episode}\n*Tipe:* ${item.type}\n*Link:* ${item.link}`
        },
        { quoted: m }
      ).catch(error => m.reply(error.message));
    }
  },
  location: 'plugins/anime/anichinpopuler.js'
};