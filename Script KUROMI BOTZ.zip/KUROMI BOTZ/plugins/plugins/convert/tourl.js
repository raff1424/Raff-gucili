let axios = require("axios"),
    FormData = require("form-data"),
    { fromBuffer } = require("file-type");

exports.run = {
  usage: ["tourl"],
  use: "reply photo/video",
  category: "convert",
  async: async (e, { kuromi: a, quoted: t }) => {
    if (!/image|video|audio|webp/.test(t.mime)) return e.reply("Reply media yang valid (gambar, video, audio, atau stiker).");

    a.sendReact(e.chat, "🕒", e.key);
    let buffer = await t.download();
    if (!buffer) return e.reply("Gagal mengunduh media.");

    let { ext, mime } = (await fromBuffer(buffer)) || {};
    let form = new FormData();
    form.append("file", buffer, { filename: "upload." + ext, contentType: mime });

    try {
      let res = await axios.post("https://cdn.nkhm.xyz/upload", form, {
        headers: {
          ...form.getHeaders(),
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36",
          Referer: "https://cdn.nkhm.xyz/"
        }
      });

      let url = res.data?.files?.[0]?.url;
      if (!url) return e.reply("Gagal mendapatkan link dari cdn.nkhm.");
      a.reply(e.chat, url, e, { expiration: e.expiration });
    } catch (err) {
      console.error(err);
      e.reply("Terjadi kesalahan saat upload ke cdn.nkhm.xyz.");
    }
  },
  limit: true,
  location: "plugins/convert/tourl.js"
};